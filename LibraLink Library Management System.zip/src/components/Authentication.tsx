import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Eye, EyeOff, Mail, Lock, User, Hash, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import GlassCard from './GlassCard';
import { UserRole, User as UserType } from '../App';
import { toast } from 'sonner@2.0.3';

interface AuthenticationProps {
  role: UserRole;
  mode: 'login' | 'register';
  onLogin: (user: UserType) => void;
  onSwitchMode: (mode: 'login' | 'register') => void;
  onBack: () => void;
}

const roleStyles = {
  student: {
    accent: 'indigo' as const,
    gradient: 'from-indigo-500 to-blue-600',
    color: 'text-indigo-400'
  },
  faculty: {
    accent: 'amber' as const,
    gradient: 'from-amber-500 to-orange-600',
    color: 'text-amber-400'
  },
  librarian: {
    accent: 'green' as const,
    gradient: 'from-green-500 to-emerald-600',
    color: 'text-green-400'
  },
  admin: {
    accent: 'red' as const,
    gradient: 'from-red-500 to-pink-600',
    color: 'text-red-400'
  }
};

export default function Authentication({ 
  role, 
  mode, 
  onLogin, 
  onSwitchMode, 
  onBack 
}: AuthenticationProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [language, setLanguage] = useState<'EN' | 'BN'>('EN');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    universityId: ''
  });
  const [passwordStrength, setPasswordStrength] = useState(0);

  const roleStyle = roleStyles[role];

  const handlePasswordChange = (password: string) => {
    setFormData(prev => ({ ...prev, password }));
    
    // Calculate password strength
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;
    if (/[^A-Za-z0-9]/.test(password)) strength += 25;
    setPasswordStrength(strength);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (mode === 'register' && passwordStrength < 50) {
      toast.error('Password must be stronger');
      return;
    }

    // Simulate authentication
    const user: UserType = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.name || 'John Doe',
      email: formData.email,
      role,
      universityId: formData.universityId
    };

    toast.success(mode === 'login' ? 'Welcome back!' : 'Account created successfully!');
    onLogin(user);
  };

  const getStrengthColor = () => {
    if (passwordStrength < 25) return 'bg-red-500';
    if (passwordStrength < 50) return 'bg-yellow-500';
    if (passwordStrength < 75) return 'bg-blue-500';
    return 'bg-green-500';
  };

  const text = {
    EN: {
      title: mode === 'login' ? 'Welcome Back' : 'Create Account',
      subtitle: mode === 'login' ? 'Sign in to your account' : 'Join LibraLink today',
      email: 'Email Address',
      password: 'Password',
      name: 'Full Name',
      universityId: 'University ID',
      submit: mode === 'login' ? 'Sign In' : 'Create Account',
      switch: mode === 'login' ? "Don't have an account?" : 'Already have an account?',
      switchAction: mode === 'login' ? 'Sign up' : 'Sign in',
      forgotPassword: 'Forgot Password?'
    },
    BN: {
      title: mode === 'login' ? 'স্বাগতম' : 'অ্যাকাউন্ট তৈরি করুন',
      subtitle: mode === 'login' ? 'আপনার অ্যাকাউন্টে সাইন ইন করুন' : 'আজই LibraLink এ যোগ দিন',
      email: 'ইমেইল ঠিকানা',
      password: 'পাসওয়ার্ড',
      name: 'পূর্ণ নাম',
      universityId: 'বিশ্ববিদ্যালয় আইডি',
      submit: mode === 'login' ? 'সাইন ইন' : 'অ্যাকাউন্ট তৈরি করুন',
      switch: mode === 'login' ? 'অ্যাকাউন্ট নেই?' : 'ইতিমধ্যে অ্যাকাউন্ট আছে?',
      switchAction: mode === 'login' ? 'সাইন আপ' : 'সাইন ইন',
      forgotPassword: 'পাসওয়ার্ড ভুলে গেছেন?'
    }
  };

  return (
    <div className="min-h-screen p-6 flex items-center justify-center relative">
      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="fixed top-6 left-6 z-50 p-3 rounded-full backdrop-blur-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-300 shadow-xl hover:scale-110"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <ArrowLeft className="w-6 h-6" />
      </motion.button>

      {/* Language Toggle */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="fixed top-6 right-6 z-50"
      >
        <div className="flex backdrop-blur-xl bg-white/10 border border-white/20 rounded-full p-1">
          {(['EN', 'BN'] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => setLanguage(lang)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                language === lang
                  ? `bg-gradient-to-r ${roleStyle.gradient} text-white shadow-lg`
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Globe className="w-4 h-4 inline mr-1" />
              {lang}
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        <GlassCard accent={roleStyle.accent} className="p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${roleStyle.gradient} flex items-center justify-center`}
              animate={{ 
                scale: [1, 1.05, 1],
                boxShadow: [
                  '0 0 20px rgba(99, 102, 241, 0.3)',
                  '0 0 30px rgba(99, 102, 241, 0.5)',
                  '0 0 20px rgba(99, 102, 241, 0.3)'
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <User className="w-8 h-8 text-white" />
            </motion.div>
            
            <h2 className="text-3xl font-bold text-white mb-2">
              {text[language].title}
            </h2>
            <p className="text-white/70">
              {text[language].subtitle}
            </p>
            <div className={`inline-block px-3 py-1 rounded-full bg-gradient-to-r ${roleStyle.gradient} text-white text-sm font-medium mt-2`}>
              {role.charAt(0).toUpperCase() + role.slice(1)}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {mode === 'register' && (
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white/90">
                  {text[language].name}
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                  <Input
                    id="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="pl-10 bg-white/10 border-white/20 text-white placeholder-white/40 focus:border-white/40 backdrop-blur-sm"
                    placeholder={text[language].name}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-white/90">
                {text[language].email}
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder-white/40 focus:border-white/40 backdrop-blur-sm"
                  placeholder={text[language].email}
                />
              </div>
            </div>

            {(mode === 'register' && (role === 'student' || role === 'faculty')) && (
              <div className="space-y-2">
                <Label htmlFor="universityId" className="text-white/90">
                  {text[language].universityId}
                </Label>
                <div className="relative">
                  <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                  <Input
                    id="universityId"
                    type="text"
                    required
                    value={formData.universityId}
                    onChange={(e) => setFormData(prev => ({ ...prev, universityId: e.target.value }))}
                    className="pl-10 bg-white/10 border-white/20 text-white placeholder-white/40 focus:border-white/40 backdrop-blur-sm"
                    placeholder={text[language].universityId}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="password" className="text-white/90">
                {text[language].password}
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={formData.password}
                  onChange={(e) => handlePasswordChange(e.target.value)}
                  className="pl-10 pr-10 bg-white/10 border-white/20 text-white placeholder-white/40 focus:border-white/40 backdrop-blur-sm"
                  placeholder={text[language].password}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/40 hover:text-white/60 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              
              {mode === 'register' && formData.password && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-2"
                >
                  <div className="flex items-center space-x-2 text-sm text-white/70">
                    <span>Strength:</span>
                    <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                      <motion.div
                        className={`h-full ${getStrengthColor()} transition-all duration-300`}
                        initial={{ width: 0 }}
                        animate={{ width: `${passwordStrength}%` }}
                      />
                    </div>
                    <span className={passwordStrength >= 75 ? 'text-green-400' : passwordStrength >= 50 ? 'text-blue-400' : 'text-red-400'}>
                      {passwordStrength >= 75 ? 'Strong' : passwordStrength >= 50 ? 'Good' : 'Weak'}
                    </span>
                  </div>
                </motion.div>
              )}
            </div>

            <Button
              type="submit"
              className={`w-full bg-gradient-to-r ${roleStyle.gradient} hover:opacity-90 text-white border-0 py-3 rounded-xl shadow-2xl transition-all duration-300 hover:scale-[1.02]`}
            >
              <motion.span
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {text[language].submit}
              </motion.span>
            </Button>

            {mode === 'login' && (
              <div className="text-center">
                <button
                  type="button"
                  className={`${roleStyle.color} hover:text-white transition-colors text-sm`}
                >
                  {text[language].forgotPassword}
                </button>
              </div>
            )}

            <div className="text-center pt-4 border-t border-white/10">
              <span className="text-white/70 text-sm">
                {text[language].switch}{' '}
              </span>
              <button
                type="button"
                onClick={() => onSwitchMode(mode === 'login' ? 'register' : 'login')}
                className={`${roleStyle.color} hover:text-white transition-colors text-sm font-medium`}
              >
                {text[language].switchAction}
              </button>
            </div>
          </form>
        </GlassCard>
      </motion.div>
    </div>
  );
}