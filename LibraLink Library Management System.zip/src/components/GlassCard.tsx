import React from 'react';
import { motion } from 'motion/react';
import { cn } from './ui/utils';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  accent?: 'indigo' | 'teal' | 'purple' | 'amber' | 'red' | 'green';
  onClick?: () => void;
}

const accentColors = {
  indigo: 'border-indigo-500/20 shadow-indigo-500/10',
  teal: 'border-teal-500/20 shadow-teal-500/10',
  purple: 'border-purple-500/20 shadow-purple-500/10',
  amber: 'border-amber-500/20 shadow-amber-500/10',
  red: 'border-red-500/20 shadow-red-500/10',
  green: 'border-green-500/20 shadow-green-500/10'
};

const hoverAccentColors = {
  indigo: 'hover:border-indigo-400/40 hover:shadow-indigo-400/20',
  teal: 'hover:border-teal-400/40 hover:shadow-teal-400/20',
  purple: 'hover:border-purple-400/40 hover:shadow-purple-400/20',
  amber: 'hover:border-amber-400/40 hover:shadow-amber-400/20',
  red: 'hover:border-red-400/40 hover:shadow-red-400/20',
  green: 'hover:border-green-400/40 hover:shadow-green-400/20'
};

export default function GlassCard({ 
  children, 
  className, 
  hover = false, 
  accent,
  onClick 
}: GlassCardProps) {
  return (
    <motion.div
      className={cn(
        // Base glass effect
        'backdrop-blur-xl bg-white/10 border border-white/20',
        'rounded-2xl shadow-2xl shadow-black/10',
        
        // Interactive states
        onClick && 'cursor-pointer',
        hover && 'transition-all duration-300 hover:bg-white/15 hover:border-white/30',
        hover && 'hover:scale-[1.02] hover:shadow-3xl hover:shadow-black/20',
        
        // Accent colors
        accent && accentColors[accent],
        accent && hover && hoverAccentColors[accent],
        
        className
      )}
      onClick={onClick}
      whileHover={hover ? { y: -2 } : undefined}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {children}
    </motion.div>
  );
}