import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  LogOut, 
  ArrowLeft, 
  AlertTriangle,
  Shield,
  Users,
  Settings,
  BarChart3,
  Bell,
  Search,
  Server,
  TrendingUp
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { User } from '../../App';
import { toast } from 'sonner@2.0.3';
import { mockAlerts } from '../../data/adminConstants';
import AdminOverviewTab from './admin/AdminOverviewTab';
import AdminUsersTab from './admin/AdminUsersTab';
import AdminSystemTab from './admin/AdminSystemTab';
import AdminAnalyticsTab from './admin/AdminAnalyticsTab';
import AdminSettingsTab from './admin/AdminSettingsTab';

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
  onBack: () => void;
}

export type AdminTab = 'overview' | 'users' | 'system' | 'analytics' | 'settings';

export default function AdminDashboard({ user, onLogout, onBack }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);

  const handleUserAction = (action: string, userId?: string) => {
    toast.success(`${action} action would be performed here`);
  };

  const handleSystemAction = (action: string) => {
    toast.success(`${action} action would be performed here`);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'system', label: 'System Health', icon: Server },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return <AdminOverviewTab onSystemAction={handleSystemAction} />;
      case 'users':
        return <AdminUsersTab onUserAction={handleUserAction} />;
      case 'system':
        return <AdminSystemTab onSystemAction={handleSystemAction} />;
      case 'analytics':
        return <AdminAnalyticsTab />;
      case 'settings':
        return <AdminSettingsTab onSystemAction={handleSystemAction} />;
      default:
        return <AdminOverviewTab onSystemAction={handleSystemAction} />;
    }
  };

  return (
    <div className="min-h-screen">
      {/* Enhanced Admin Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-red-900 via-pink-900 to-purple-900" />
        <motion.div
          className="absolute inset-0"
          animate={{
            background: [
              'radial-gradient(circle at 20% 20%, rgba(239, 68, 68, 0.4) 0%, transparent 50%)',
              'radial-gradient(circle at 80% 80%, rgba(236, 72, 153, 0.4) 0%, transparent 50%)',
              'radial-gradient(circle at 40% 60%, rgba(147, 51, 234, 0.4) 0%, transparent 50%)',
              'radial-gradient(circle at 20% 20%, rgba(239, 68, 68, 0.4) 0%, transparent 50%)'
            ]
          }}
          transition={{
            duration: 16,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
      </div>

      {/* Enhanced Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative backdrop-blur-3xl bg-white/5 border-b border-white/10 shadow-2xl"
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Section */}
            <div className="flex items-center space-x-4">
              <motion.button
                onClick={onBack}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20 text-white shadow-lg"
                whileHover={{ scale: 1.05, rotate: -5 }}
                whileTap={{ scale: 0.95 }}
              >
                <ArrowLeft className="w-5 h-5" />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-red-500/20 to-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
              
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent">
                  System Administration
                </h1>
                <p className="text-white/70 flex items-center space-x-2">
                  <Shield className="w-4 h-4" />
                  <span>Admin Dashboard - {user.name}</span>
                </p>
              </div>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-4">
              {/* Enhanced Search */}
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40 group-focus-within:text-white/70 transition-colors" />
                <Input
                  placeholder="Search users, logs, settings..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 w-80 h-12 bg-gradient-to-r from-white/10 to-white/5 border-white/20 text-white placeholder-white/40 focus:border-red-400/50 backdrop-blur-xl rounded-2xl shadow-lg"
                />
              </div>

              {/* System Status */}
              <motion.div
                className="flex items-center space-x-2 px-4 py-2 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                <span className="text-white/80 text-sm font-medium">System Online</span>
              </motion.div>

              {/* Notifications */}
              <motion.button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20 text-white shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Bell className="w-6 h-6" />
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg"
                >
                  {mockAlerts.length}
                </motion.span>
              </motion.button>

              {/* Emergency Button */}
              <Button 
                className="h-12 px-6 bg-gradient-to-r from-red-500 via-pink-500 to-purple-500 hover:from-red-600 hover:via-pink-600 hover:to-purple-600 text-white border-0 rounded-2xl shadow-xl backdrop-blur-xl font-medium"
              >
                <AlertTriangle className="w-5 h-5 mr-2" />
                Emergency
              </Button>

              {/* Logout */}
              <Button
                onClick={onLogout}
                variant="outline"
                className="h-12 border-white/20 text-white hover:bg-white/10 rounded-2xl backdrop-blur-xl"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </motion.header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Enhanced Navigation Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex space-x-2 mb-8 overflow-x-auto"
        >
          {tabs.map((tab) => (
            <motion.button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AdminTab)}
              className={`flex items-center space-x-3 px-6 py-3 rounded-2xl transition-all duration-300 whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-red-500 via-pink-500 to-purple-500 text-white shadow-lg'
                  : 'bg-white/10 text-white/70 hover:bg-white/20 backdrop-blur-xl'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <tab.icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
            </motion.button>
          ))}
        </motion.div>

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {renderTabContent()}
        </motion.div>
      </div>
    </div>
  );
}