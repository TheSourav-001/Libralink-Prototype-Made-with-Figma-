import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Bell, 
  Heart, 
  BookOpen, 
  CreditCard, 
  LogOut, 
  ArrowLeft,
  Sparkles,
  Filter,
  Grid3X3,
  List,
  Star,
  Clock,
  User,
  MessageCircle,
  Calendar,
  Download,
  BookMarked,
  History,
  TrendingUp,
  Award,
  FileText,
  Play,
  Pause,
  Volume2,
  VolumeX,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Bookmark,
  AlertCircle,
  CheckCircle,
  MapPin,
  Filter as FilterIcon,
  SortAsc,
  Eye,
  Plus,
  Minus,
  X
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Slider } from '../ui/slider';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import GlassCard from '../GlassCard';
import BookCard from '../BookCard';
import PaymentSystem from '../PaymentSystem';
import { User as UserType } from '../../App';
import { allBooks, searchBooks, getBorrowedBooks, Book } from '../../data/books';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner@2.0.3';

interface StudentDashboardProps {
  user: UserType;
  onLogout: () => void;
  onBack: () => void;
}

interface Notification {
  id: string;
  type: 'due' | 'reserved' | 'fine' | 'reminder' | 'recommendation' | 'overdue';
  title: string;
  message: string;
  timestamp: string;
  unread: boolean;
  priority: 'low' | 'medium' | 'high';
}

interface BorrowHistory {
  id: string;
  book: Book;
  borrowDate: string;
  returnDate?: string;
  dueDate: string;
  status: 'returned' | 'overdue' | 'current';
  renewalCount: number;
  rating?: number;
  review?: string;
}

interface EBook {
  id: string;
  title: string;
  author: string;
  coverUrl: string;
  fileUrl: string;
  category: string;
  description: string;
  rating: number;
  totalPages: number;
  readingProgress: number;
  lastRead?: string;
  audioUrl?: string;
  downloadable: boolean;
}

interface ReadingSession {
  id: string;
  bookId: string;
  startTime: string;
  endTime?: string;
  pagesRead: number;
  totalTime: number;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'due',
    title: 'Book Due Tomorrow',
    message: '"Introduction to Algorithms" is due tomorrow. Renew now to avoid late fees.',
    timestamp: '2 hours ago',
    unread: true,
    priority: 'high'
  },
  {
    id: '2',
    type: 'reserved',
    title: 'Reserved Book Available',
    message: '"Clean Code" is now available for pickup at the main library.',
    timestamp: '1 day ago',
    unread: true,
    priority: 'medium'
  },
  {
    id: '3',
    type: 'recommendation',
    title: 'New AI Recommendation',
    message: 'Based on your reading history, we think you\'ll love "The Pragmatic Programmer"',
    timestamp: '2 days ago',
    unread: false,
    priority: 'low'
  },
  {
    id: '4',
    type: 'overdue',
    title: 'Overdue Book',
    message: '"Design Patterns" is now overdue. Please return immediately to avoid additional fees.',
    timestamp: '3 days ago',
    unread: true,
    priority: 'high'
  }
];

const mockBorrowHistory: BorrowHistory[] = [
  {
    id: '1',
    book: allBooks[0],
    borrowDate: '2024-01-15',
    returnDate: '2024-02-15',
    dueDate: '2024-02-15',
    status: 'returned',
    renewalCount: 1,
    rating: 5,
    review: 'Excellent book on algorithms. Very comprehensive and well-explained.'
  },
  {
    id: '2',
    book: allBooks[1],
    borrowDate: '2024-02-01',
    dueDate: '2024-02-28',
    status: 'current',
    renewalCount: 0
  },
  {
    id: '3',
    book: allBooks[2],
    borrowDate: '2024-01-01',
    returnDate: '2024-01-20',
    dueDate: '2024-01-30',
    status: 'returned',
    renewalCount: 0,
    rating: 4
  }
];

const mockEBooks: EBook[] = [
  {
    id: 'e1',
    title: 'Digital Libraries: The Complete Guide',
    author: 'Sarah Johnson',
    coverUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=600&fit=crop',
    fileUrl: '/ebooks/digital-libraries.pdf',
    category: 'Technology',
    description: 'A comprehensive guide to modern digital library systems and their implementation.',
    rating: 4.7,
    totalPages: 312,
    readingProgress: 45,
    lastRead: '2024-02-20',
    audioUrl: '/audiobooks/digital-libraries.mp3',
    downloadable: true
  },
  {
    id: 'e2',
    title: 'Machine Learning Foundations',
    author: 'Dr. Michael Chen',
    coverUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop',
    fileUrl: '/ebooks/ml-foundations.pdf',
    category: 'Science',
    description: 'Essential concepts and practical applications of machine learning algorithms.',
    rating: 4.9,
    totalPages: 428,
    readingProgress: 12,
    lastRead: '2024-02-18',
    downloadable: false
  },
  {
    id: 'e3',
    title: 'Modern Web Development',
    author: 'Alex Rivera',
    coverUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=600&fit=crop',
    fileUrl: '/ebooks/web-dev.pdf',
    category: 'Technology',
    description: 'Latest techniques and frameworks for building modern web applications.',
    rating: 4.5,
    totalPages: 256,
    readingProgress: 78,
    lastRead: '2024-02-19',
    audioUrl: '/audiobooks/web-dev.mp3',
    downloadable: true
  }
];

export default function StudentDashboard({ user, onLogout, onBack }: StudentDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showBookDetails, setShowBookDetails] = useState<Book | null>(null);
  const [showPaymentSystem, setShowPaymentSystem] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);
  const [wishlist, setWishlist] = useState<string[]>(['1', '5', '12']);
  const [reservedBooks, setReservedBooks] = useState<string[]>(['3', '8']);
  const [borrowHistory, setBorrowHistory] = useState(mockBorrowHistory);
  const [eBooks, setEBooks] = useState(mockEBooks);
  const [activeTab, setActiveTab] = useState('browse');
  const [sortBy, setSortBy] = useState<'relevance' | 'rating' | 'date' | 'title'>('relevance');
  const [filterOptions, setFilterOptions] = useState({
    availability: 'all',
    rating: [0],
    category: 'all'
  });
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [readingSessions, setReadingSessions] = useState<ReadingSession[]>([]);
  const [currentlyReading, setCurrentlyReading] = useState<string | null>(null);
  const [audioPlaying, setAudioPlaying] = useState<string | null>(null);

  const borrowedBooks = getBorrowedBooks(user.id);
  
  // Enhanced search and filtering logic
  const getFilteredBooks = () => {
    let books = searchQuery ? searchBooks(searchQuery) : allBooks;
    
    // Apply category filter
    if (selectedCategory !== 'all') {
      books = books.filter(book => book.category.toLowerCase() === selectedCategory);
    }
    
    // Apply advanced filters
    if (filterOptions.availability !== 'all') {
      books = books.filter(book => book.status === filterOptions.availability);
    }
    
    if (filterOptions.rating[0] > 0) {
      books = books.filter(book => book.rating >= filterOptions.rating[0]);
    }
    
    if (filterOptions.category !== 'all') {
      books = books.filter(book => book.category.toLowerCase() === filterOptions.category);
    }
    
    // Apply sorting
    books.sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.rating - a.rating;
        case 'title':
          return a.title.localeCompare(b.title);
        case 'date':
          return new Date(b.publishedDate || '').getTime() - new Date(a.publishedDate || '').getTime();
        default:
          return 0;
      }
    });
    
    return books;
  };

  const filteredBooks = getFilteredBooks();
  const categories = ['all', 'fiction', 'science', 'technology', 'fantasy', 'business', 'self-help', 'history', 'biography'];
  
  // Enhanced AI suggestions with machine learning simulation
  const aiSuggestions = allBooks.filter(book => {
    const userCategories = borrowHistory.map(h => h.book.category.toLowerCase());
    const userRatings = borrowHistory.filter(h => h.rating).map(h => h.rating!);
    const avgUserRating = userRatings.length > 0 ? userRatings.reduce((a, b) => a + b, 0) / userRatings.length : 4;
    
    return (
      book.rating >= avgUserRating - 0.5 && 
      book.status === 'available' &&
      (userCategories.includes(book.category.toLowerCase()) || book.rating > 4.5)
    );
  }).slice(0, 8);

  const unreadCount = notifications.filter(n => n.unread).length;
  const overdueBooks = borrowedBooks.filter(book => 
    book.dueDate && new Date(book.dueDate) < new Date()
  );

  // Calculate reading statistics
  const totalBooksRead = borrowHistory.filter(h => h.status === 'returned').length;
  const totalReadingTime = readingSessions.reduce((total, session) => total + session.totalTime, 0);
  const averageRating = borrowHistory.filter(h => h.rating).reduce((acc, h) => acc + h.rating!, 0) / borrowHistory.filter(h => h.rating).length || 0;

  useEffect(() => {
    // Simulate real-time notifications
    const interval = setInterval(() => {
      if (Math.random() > 0.98) {
        const newNotification: Notification = {
          id: Date.now().toString(),
          type: 'recommendation',
          title: 'New Book Recommendation',
          message: 'A new book matching your interests is now available!',
          timestamp: 'Just now',
          unread: true,
          priority: 'low'
        };
        setNotifications(prev => [newNotification, ...prev].slice(0, 10));
      }
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('[data-dropdown]')) {
        setShowNotifications(false);
        setShowAdvancedSearch(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleBookClick = (book: Book) => {
    setShowBookDetails(book);
  };

  const handleBorrowBook = (book: Book) => {
    if (book.status === 'available') {
      toast.success(`"${book.title}" has been borrowed successfully!`);
      const newHistoryEntry: BorrowHistory = {
        id: Date.now().toString(),
        book,
        borrowDate: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'current',
        renewalCount: 0
      };
      setBorrowHistory(prev => [newHistoryEntry, ...prev]);
    } else {
      setReservedBooks(prev => [...prev, book.id]);
      toast.info(`"${book.title}" has been added to your reservation list.`);
    }
    setShowBookDetails(null);
  };

  const handleReserveBook = (book: Book) => {
    if (!reservedBooks.includes(book.id)) {
      setReservedBooks(prev => [...prev, book.id]);
      toast.success(`"${book.title}" has been reserved successfully!`);
    } else {
      toast.info('This book is already in your reservations.');
    }
  };

  const handleWishlistToggle = (bookId: string) => {
    setWishlist(prev => 
      prev.includes(bookId) 
        ? prev.filter(id => id !== bookId)
        : [...prev, bookId]
    );
    
    const book = allBooks.find(b => b.id === bookId);
    if (book) {
      if (wishlist.includes(bookId)) {
        toast.success(`"${book.title}" removed from wishlist`);
      } else {
        toast.success(`"${book.title}" added to wishlist`);
      }
    }
  };

  const handleRenewBook = (book: Book) => {
    setBorrowHistory(prev => 
      prev.map(h => 
        h.book.id === book.id && h.status === 'current'
          ? { 
              ...h, 
              renewalCount: h.renewalCount + 1,
              dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
            }
          : h
      )
    );
    toast.success(`"${book.title}" has been renewed for 2 more weeks!`);
  };

  const handleRateBook = (bookId: string, rating: number, review?: string) => {
    setBorrowHistory(prev => 
      prev.map(h => 
        h.book.id === bookId 
          ? { ...h, rating, review }
          : h
      )
    );
    toast.success('Thank you for your rating!');
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, unread: false } : n)
    );
  };

  const clearAllFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setFilterOptions({
      availability: 'all',
      rating: [0],
      category: 'all'
    });
    setSortBy('relevance');
    setShowAdvancedSearch(false);
  };

  const startReadingSession = (bookId: string) => {
    setCurrentlyReading(bookId);
    const session: ReadingSession = {
      id: Date.now().toString(),
      bookId,
      startTime: new Date().toISOString(),
      pagesRead: 0,
      totalTime: 0
    };
    setReadingSessions(prev => [...prev, session]);
  };

  const endReadingSession = (pagesRead: number) => {
    if (currentlyReading) {
      setReadingSessions(prev => 
        prev.map(session => 
          session.bookId === currentlyReading && !session.endTime
            ? {
                ...session,
                endTime: new Date().toISOString(),
                pagesRead,
                totalTime: Date.now() - new Date(session.startTime).getTime()
              }
            : session
        )
      );
      setCurrentlyReading(null);
      toast.success(`Reading session completed! You read ${pagesRead} pages.`);
    }
  };

  const toggleAudioPlayback = (bookId: string) => {
    if (audioPlaying === bookId) {
      setAudioPlaying(null);
      toast.info('Audiobook paused');
    } else {
      setAudioPlaying(bookId);
      toast.success('Audiobook playing');
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* Enhanced iOS 26 Dynamic Background with Liquid Glass Effect */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-blue-900 to-purple-900" />
        <motion.div
          className="absolute inset-0"
          animate={{
            background: [
              'radial-gradient(circle at 20% 20%, rgba(99, 102, 241, 0.4) 0%, transparent 70%)',
              'radial-gradient(circle at 80% 80%, rgba(139, 92, 246, 0.4) 0%, transparent 70%)',
              'radial-gradient(circle at 40% 60%, rgba(59, 130, 246, 0.4) 0%, transparent 70%)',
              'radial-gradient(circle at 60% 20%, rgba(147, 51, 234, 0.4) 0%, transparent 70%)',
              'radial-gradient(circle at 20% 20%, rgba(99, 102, 241, 0.4) 0%, transparent 70%)'
            ]
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        {/* Ultra Realistic Liquid Glass Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent backdrop-blur-[1px]" />
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-black/10" />
      </div>

      {/* Enhanced Header with Liquid Glass */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative backdrop-blur-3xl bg-white/[0.02] border-b border-white/[0.08] shadow-2xl sticky top-0 z-[100]"
        style={{
          backdropFilter: 'blur(40px) saturate(180%)',
          WebkitBackdropFilter: 'blur(40px) saturate(180%)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-white/[0.03] via-white/[0.01] to-white/[0.03]" />
        <div className="relative max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Section */}
            <div className="flex items-center space-x-4">
              <motion.button
                onClick={onBack}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/[0.15] to-white/[0.08] border border-white/[0.2] text-white shadow-2xl overflow-hidden"
                whileHover={{ scale: 1.05, rotate: -5 }}
                whileTap={{ scale: 0.95 }}
                style={{
                  backdropFilter: 'blur(20px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                }}
              >
                <ArrowLeft className="w-5 h-5 relative z-10" />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-indigo-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute inset-0 rounded-2xl bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </motion.button>
              
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-white via-indigo-200 to-white bg-clip-text text-transparent">
                  Welcome back, {user.name}!
                </h1>
                <p className="text-white/70 flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>Student Dashboard</span>
                  {overdueBooks.length > 0 && (
                    <Badge className="bg-red-500/20 text-red-400 border-red-500/30 ml-2">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {overdueBooks.length} Overdue
                    </Badge>
                  )}
                </p>
              </div>
            </div>

            {/* Center Section - Enhanced Search */}
            <div className="flex-1 max-w-2xl mx-8">
              <div className="relative group" data-dropdown>
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40 group-focus-within:text-white/70 transition-colors z-10" />
                <Input
                  placeholder="Search books, authors, topics, ISBN..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-16 w-full h-12 bg-gradient-to-r from-white/[0.12] to-white/[0.08] border-white/[0.15] text-white placeholder-white/40 focus:border-indigo-400/50 backdrop-blur-xl rounded-2xl shadow-lg transition-all duration-300 focus:shadow-2xl"
                  style={{
                    backdropFilter: 'blur(20px) saturate(180%)',
                    WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                  }}
                />
                <Button
                  onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
                  variant="ghost"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg z-10"
                >
                  <FilterIcon className="w-4 h-4" />
                </Button>
              </div>

              {/* Enhanced Advanced Search Panel */}
              <AnimatePresence>
                {showAdvancedSearch && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    className="absolute top-full left-0 right-0 mt-2 z-[200]"
                    data-dropdown
                  >
                    <div 
                      className="backdrop-blur-3xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-2xl p-6"
                      style={{
                        backdropFilter: 'blur(40px) saturate(180%)',
                        WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                      }}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">Advanced Search</h3>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={clearAllFilters}
                            variant="ghost"
                            size="sm"
                            className="text-white/60 hover:text-white hover:bg-white/10"
                          >
                            Clear All
                          </Button>
                          <Button
                            onClick={() => setShowAdvancedSearch(false)}
                            variant="ghost"
                            size="sm"
                            className="text-white/60 hover:text-white hover:bg-white/10 p-1"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                          <label className="text-white/70 text-sm mb-2 block">Availability</label>
                          <Select 
                            value={filterOptions.availability} 
                            onValueChange={(value) => setFilterOptions(prev => ({ ...prev, availability: value }))}
                          >
                            <SelectTrigger className="bg-white/10 border-white/20 text-white backdrop-blur-xl">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-900/95 backdrop-blur-xl border-white/20">
                              <SelectItem value="all">All Books</SelectItem>
                              <SelectItem value="available">Available</SelectItem>
                              <SelectItem value="borrowed">Borrowed</SelectItem>
                              <SelectItem value="reserved">Reserved</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <label className="text-white/70 text-sm mb-2 block">Category</label>
                          <Select 
                            value={filterOptions.category} 
                            onValueChange={(value) => setFilterOptions(prev => ({ ...prev, category: value }))}
                          >
                            <SelectTrigger className="bg-white/10 border-white/20 text-white backdrop-blur-xl">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-900/95 backdrop-blur-xl border-white/20">
                              {categories.map(category => (
                                <SelectItem key={category} value={category}>
                                  {category.charAt(0).toUpperCase() + category.slice(1)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <label className="text-white/70 text-sm mb-2 block">Minimum Rating</label>
                          <div className="space-y-2">
                            <Slider
                              value={filterOptions.rating}
                              onValueChange={(value) => setFilterOptions(prev => ({ ...prev, rating: value }))}
                              max={5}
                              min={0}
                              step={0.5}
                              className="mt-2"
                            />
                            <div className="text-white/60 text-xs">{filterOptions.rating[0]} stars and above</div>
                          </div>
                        </div>
                        
                        <div>
                          <label className="text-white/70 text-sm mb-2 block">Sort By</label>
                          <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                            <SelectTrigger className="bg-white/10 border-white/20 text-white backdrop-blur-xl">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-900/95 backdrop-blur-xl border-white/20">
                              <SelectItem value="relevance">Relevance</SelectItem>
                              <SelectItem value="rating">Rating</SelectItem>
                              <SelectItem value="title">Title</SelectItem>
                              <SelectItem value="date">Publication Date</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="mt-4 pt-4 border-t border-white/10">
                        <div className="text-white/60 text-sm">
                          Showing {filteredBooks.length} books
                          {searchQuery && ` for "${searchQuery}"`}
                          {selectedCategory !== 'all' && ` in ${selectedCategory}`}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-4">
              {/* Enhanced Notifications */}
              <div className="relative" data-dropdown>
                <motion.button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/[0.15] to-white/[0.08] border border-white/[0.2] text-white shadow-2xl overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  style={{
                    backdropFilter: 'blur(20px) saturate(180%)',
                    WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                  }}
                >
                  <Bell className="w-6 h-6 relative z-10" />
                  {unreadCount > 0 && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg z-10"
                    >
                      {unreadCount}
                    </motion.span>
                  )}
                  <div className="absolute inset-0 rounded-2xl bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </motion.button>

                {/* Enhanced Notifications Dropdown */}
                <AnimatePresence>
                  {showNotifications && (
                    <motion.div
                      initial={{ opacity: 0, y: -10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.95 }}
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                      className="absolute top-full right-0 mt-2 w-96 z-[300]"
                      data-dropdown
                    >
                      <div 
                        className="backdrop-blur-3xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-2xl p-6"
                        style={{
                          backdropFilter: 'blur(40px) saturate(180%)',
                          WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                        }}
                      >
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-xl font-bold text-white">Notifications</h3>
                          <div className="flex items-center space-x-2">
                            <Badge className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30">
                              {unreadCount} new
                            </Badge>
                            <Button
                              onClick={() => setShowNotifications(false)}
                              variant="ghost"
                              size="sm"
                              className="text-white/60 hover:text-white hover:bg-white/10 p-1"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-3 max-h-80 overflow-y-auto">
                          {notifications.map((notification) => (
                            <motion.div
                              key={notification.id}
                              onClick={() => markNotificationAsRead(notification.id)}
                              className={`p-4 rounded-xl cursor-pointer transition-all duration-300 ${
                                notification.unread ? 'bg-white/10' : 'bg-white/5'
                              } hover:bg-white/15`}
                              whileHover={{ x: 5 }}
                            >
                              <div className="flex items-start space-x-3">
                                <div className={`w-3 h-3 rounded-full mt-2 ${
                                  notification.priority === 'high' ? 'bg-red-400' :
                                  notification.priority === 'medium' ? 'bg-yellow-400' : 'bg-blue-400'
                                }`} />
                                <div className="flex-1">
                                  <h4 className="font-medium text-white">{notification.title}</h4>
                                  <p className="text-white/70 text-sm">{notification.message}</p>
                                  <div className="flex items-center justify-between mt-2">
                                    <p className="text-white/50 text-xs">{notification.timestamp}</p>
                                    <Badge className={`text-xs ${
                                      notification.type === 'due' || notification.type === 'overdue' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                                      notification.type === 'reserved' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                                      'bg-blue-500/20 text-blue-400 border-blue-500/30'
                                    }`}>
                                      {notification.type}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Enhanced Pay Fees Button */}
              <Button 
                onClick={() => setShowPaymentSystem(true)}
                className="h-12 px-6 bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:from-emerald-600 hover:via-green-600 hover:to-teal-600 text-white border-0 rounded-2xl shadow-xl backdrop-blur-xl font-medium transition-all duration-300"
                style={{
                  backdropFilter: 'blur(20px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                }}
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Pay Fees
              </Button>

              {/* Enhanced Logout */}
              <Button
                onClick={onLogout}
                variant="outline"
                className="h-12 border-white/20 text-white hover:bg-white/10 rounded-2xl backdrop-blur-xl transition-all duration-300"
                style={{
                  backdropFilter: 'blur(20px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                }}
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </motion.header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Enhanced Navigation Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList 
              className="grid w-full grid-cols-6 bg-white/[0.08] backdrop-blur-xl border border-white/[0.15] rounded-2xl p-2"
              style={{
                backdropFilter: 'blur(20px) saturate(180%)',
                WebkitBackdropFilter: 'blur(20px) saturate(180%)',
              }}
            >
              <TabsTrigger value="browse" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-blue-500 data-[state=active]:text-white text-white/70 rounded-xl transition-all duration-300">
                <BookOpen className="w-4 h-4 mr-2" />
                Browse
              </TabsTrigger>
              <TabsTrigger value="borrowed" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-blue-500 data-[state=active]:text-white text-white/70 rounded-xl transition-all duration-300">
                <BookMarked className="w-4 h-4 mr-2" />
                Borrowed
              </TabsTrigger>
              <TabsTrigger value="history" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-blue-500 data-[state=active]:text-white text-white/70 rounded-xl transition-all duration-300">
                <History className="w-4 h-4 mr-2" />
                History
              </TabsTrigger>
              <TabsTrigger value="ebooks" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-blue-500 data-[state=active]:text-white text-white/70 rounded-xl transition-all duration-300">
                <FileText className="w-4 h-4 mr-2" />
                eBooks
              </TabsTrigger>
              <TabsTrigger value="wishlist" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-blue-500 data-[state=active]:text-white text-white/70 rounded-xl transition-all duration-300">
                <Heart className="w-4 h-4 mr-2" />
                Wishlist
              </TabsTrigger>
              <TabsTrigger value="analytics" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-blue-500 data-[state=active]:text-white text-white/70 rounded-xl transition-all duration-300">
                <TrendingUp className="w-4 h-4 mr-2" />
                Analytics
              </TabsTrigger>
            </TabsList>

            {/* Enhanced Quick Stats */}
            <motion.section
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="mt-8 mb-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                {[
                  { icon: BookOpen, value: borrowedBooks.length, label: 'Current Books', accent: 'indigo', color: 'from-indigo-500 to-blue-500' },
                  { icon: Heart, value: wishlist.length, label: 'Wishlist', accent: 'green', color: 'from-green-500 to-emerald-500' },
                  { icon: Award, value: totalBooksRead, label: 'Books Read', accent: 'amber', color: 'from-amber-500 to-orange-500' },
                  { icon: Star, value: averageRating.toFixed(1), label: 'Avg Rating', accent: 'purple', color: 'from-purple-500 to-pink-500' },
                  { icon: MapPin, value: reservedBooks.length, label: 'Reserved', accent: 'teal', color: 'from-teal-500 to-cyan-500' }
                ].map((stat, index) => (
                  <motion.div 
                    key={index}
                    whileHover={{ y: -5, scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  >
                    <div 
                      className="p-6 text-center group cursor-pointer backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300"
                      style={{
                        backdropFilter: 'blur(20px) saturate(180%)',
                        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                      }}
                    >
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 10 }}
                        className={`w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}
                      >
                        <stat.icon className="w-6 h-6 text-white" />
                      </motion.div>
                      <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                      <div className="text-white/70">{stat.label}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.section>

            {/* Tab Contents */}
            <TabsContent value="browse" className="space-y-8">
              {/* Enhanced AI Suggestions */}
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <div className="flex items-center space-x-3 mb-6">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                  >
                    <Sparkles className="w-8 h-8 text-indigo-400" />
                  </motion.div>
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
                    AI Recommendations
                  </h2>
                  <Badge className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border border-purple-500/30">
                    Smart Picks
                  </Badge>
                </div>
                
                <div className="flex space-x-6 overflow-x-auto pb-6" style={{ scrollbarWidth: 'thin' }}>
                  {aiSuggestions.map((book, index) => (
                    <motion.div
                      key={book.id}
                      initial={{ opacity: 0, x: 50 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                      className="flex-shrink-0"
                    >
                      <div className="relative">
                        <BookCard
                          book={book}
                          onClick={handleBookClick}
                          size="medium"
                        />
                        <motion.div
                          className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: index * 0.1 + 0.5, type: "spring", stiffness: 400, damping: 20 }}
                        >
                          <Sparkles className="w-3 h-3 text-white" />
                        </motion.div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.section>

              {/* Enhanced Category Filter */}
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
                    Browse Library ({filteredBooks.length} books)
                  </h2>
                  <div className="flex items-center space-x-4">
                    {/* Enhanced View Mode Toggle */}
                    <div 
                      className="p-2 flex items-center space-x-2 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                      style={{
                        backdropFilter: 'blur(20px) saturate(180%)',
                        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                      }}
                    >
                      <motion.button
                        onClick={() => setViewMode('grid')}
                        className={`p-3 rounded-xl transition-all duration-300 ${
                          viewMode === 'grid' 
                            ? 'bg-gradient-to-r from-indigo-500 to-blue-500 text-white shadow-lg' 
                            : 'text-white/60 hover:text-white hover:bg-white/10'
                        }`}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Grid3X3 className="w-5 h-5" />
                      </motion.button>
                      <motion.button
                        onClick={() => setViewMode('list')}
                        className={`p-3 rounded-xl transition-all duration-300 ${
                          viewMode === 'list' 
                            ? 'bg-gradient-to-r from-indigo-500 to-blue-500 text-white shadow-lg' 
                            : 'text-white/60 hover:text-white hover:bg-white/10'
                        }`}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <List className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </div>
                </div>

                {/* Enhanced Category Pills */}
                <div className="flex space-x-2 overflow-x-auto pb-4 mb-6" style={{ scrollbarWidth: 'thin' }}>
                  {categories.map((category) => (
                    <motion.button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 whitespace-nowrap ${
                        selectedCategory === category
                          ? 'bg-gradient-to-r from-indigo-500 via-blue-500 to-purple-500 text-white shadow-lg'
                          : 'bg-white/10 text-white/70 hover:bg-white/20 backdrop-blur-xl'
                      }`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{
                        backdropFilter: selectedCategory !== category ? 'blur(20px) saturate(180%)' : undefined,
                        WebkitBackdropFilter: selectedCategory !== category ? 'blur(20px) saturate(180%)' : undefined,
                      }}
                    >
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </motion.button>
                  ))}
                </div>

                {/* Enhanced Books Display */}
                <div className={`${
                  viewMode === 'grid' 
                    ? 'grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6' 
                    : 'space-y-4'
                }`}>
                  {filteredBooks.slice(0, 60).map((book, index) => (
                    viewMode === 'grid' ? (
                      <motion.div
                        key={book.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.03, type: "spring", stiffness: 300, damping: 25 }}
                      >
                        <div className="relative group">
                          <BookCard
                            book={book}
                            onClick={handleBookClick}
                            size="small"
                          />
                          {wishlist.includes(book.id) && (
                            <motion.div
                              className="absolute top-2 right-2 p-2 bg-red-500/80 rounded-full backdrop-blur-xl shadow-lg"
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              style={{
                                backdropFilter: 'blur(10px)',
                                WebkitBackdropFilter: 'blur(10px)',
                              }}
                            >
                              <Heart className="w-3 h-3 text-white fill-current" />
                            </motion.div>
                          )}
                          {reservedBooks.includes(book.id) && (
                            <motion.div
                              className="absolute top-2 left-2 p-2 bg-amber-500/80 rounded-full backdrop-blur-xl shadow-lg"
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              style={{
                                backdropFilter: 'blur(10px)',
                                WebkitBackdropFilter: 'blur(10px)',
                              }}
                            >
                              <Bookmark className="w-3 h-3 text-white fill-current" />
                            </motion.div>
                          )}
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key={book.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.02, type: "spring", stiffness: 300, damping: 25 }}
                      >
                        <div 
                          className="p-6 cursor-pointer backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:bg-white/[0.12]"
                          onClick={() => handleBookClick(book)}
                          style={{
                            backdropFilter: 'blur(20px) saturate(180%)',
                            WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                          }}
                        >
                          <div className="flex items-center space-x-6">
                            <ImageWithFallback
                              src={book.coverUrl}
                              alt={book.title}
                              className="w-16 h-20 object-cover rounded-xl shadow-lg"
                            />
                            <div className="flex-1">
                              <h3 className="text-lg font-bold text-white mb-1">{book.title}</h3>
                              <p className="text-white/70 mb-2">by {book.author}</p>
                              <div className="flex items-center space-x-3 mb-2">
                                <Badge className={`${
                                  book.status === 'available' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                                  book.status === 'borrowed' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                                  'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                                }`}>
                                  {book.status}
                                </Badge>
                                <span className="text-white/60 text-sm">{book.category}</span>
                                <div className="flex items-center space-x-1">
                                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                                  <span className="text-white/80 text-sm">{book.rating}</span>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                {wishlist.includes(book.id) && (
                                  <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">
                                    <Heart className="w-3 h-3 mr-1 fill-current" />
                                    Wishlist
                                  </Badge>
                                )}
                                {reservedBooks.includes(book.id) && (
                                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                                    <Bookmark className="w-3 h-3 mr-1 fill-current" />
                                    Reserved
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="flex flex-col space-y-2">
                              <Button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (book.status === 'available') {
                                    handleBorrowBook(book);
                                  } else {
                                    handleReserveBook(book);
                                  }
                                }}
                                className="bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 rounded-xl transition-all duration-300"
                                size="sm"
                              >
                                {book.status === 'available' ? 'Borrow' : 'Reserve'}
                              </Button>
                              <Button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleWishlistToggle(book.id);
                                }}
                                variant="outline"
                                className="border-white/20 text-white hover:bg-white/10 rounded-xl transition-all duration-300"
                                size="sm"
                              >
                                <Heart className={`w-4 h-4 ${wishlist.includes(book.id) ? 'fill-current text-red-400' : ''}`} />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )
                  ))}
                </div>
              </motion.section>
            </TabsContent>

            <TabsContent value="borrowed" className="space-y-6">
              {/* Current Borrowed Books */}
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
                    Currently Borrowed ({borrowedBooks.length})
                  </h2>
                  {overdueBooks.length > 0 && (
                    <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                      <AlertCircle className="w-4 h-4 mr-1" />
                      {overdueBooks.length} Overdue
                    </Badge>
                  )}
                </div>

                {borrowedBooks.length > 0 ? (
                  <div className="space-y-4">
                    {borrowedBooks.map((book, index) => {
                      const historyEntry = borrowHistory.find(h => h.book.id === book.id && h.status === 'current');
                      const daysUntilDue = book.dueDate ? Math.ceil((new Date(book.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
                      const isOverdue = daysUntilDue < 0;
                      
                      return (
                        <motion.div 
                          key={book.id} 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                        >
                          <div 
                            className={`p-6 cursor-pointer backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:bg-white/[0.12] ${
                              isOverdue ? 'border-red-500/50 bg-red-500/5' : ''
                            }`} 
                            onClick={() => handleBookClick(book)}
                            style={{
                              backdropFilter: 'blur(20px) saturate(180%)',
                              WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                            }}
                          >
                            <div className="flex items-center space-x-6">
                              <ImageWithFallback
                                src={book.coverUrl}
                                alt={book.title}
                                className="w-24 h-32 object-cover rounded-xl shadow-lg"
                              />
                              <div className="flex-1">
                                <h3 className="text-xl font-bold text-white mb-2">{book.title}</h3>
                                <p className="text-white/70 mb-3">by {book.author}</p>
                                
                                {book.dueDate && (
                                  <div className="space-y-2 mb-4">
                                    <div className="flex items-center space-x-3">
                                      <Clock className="w-4 h-4 text-white/60" />
                                      <span className="text-white/70">
                                        Due: {new Date(book.dueDate).toLocaleDateString()}
                                      </span>
                                      <Badge className={`${
                                        isOverdue ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                                        daysUntilDue <= 3 ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                                        'bg-green-500/20 text-green-400 border-green-500/30'
                                      }`}>
                                        {isOverdue ? `${Math.abs(daysUntilDue)} days overdue` :
                                         daysUntilDue === 0 ? 'Due today' :
                                         `${daysUntilDue} days left`}
                                      </Badge>
                                    </div>
                                    
                                    {historyEntry && (
                                      <div className="flex items-center space-x-3">
                                        <RotateCcw className="w-4 h-4 text-white/60" />
                                        <span className="text-white/70 text-sm">
                                          Renewed {historyEntry.renewalCount} times
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                )}

                                <div className="flex items-center space-x-2">
                                  <div className="flex items-center space-x-1">
                                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                                    <span className="text-white/80 text-sm">{book.rating}</span>
                                  </div>
                                  <Badge className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30 text-xs">
                                    {book.category}
                                  </Badge>
                                </div>
                              </div>
                              
                              <div className="flex flex-col space-y-3">
                                <Button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRenewBook(book);
                                  }}
                                  className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-xl transition-all duration-300"
                                  disabled={historyEntry?.renewalCount >= 3}
                                >
                                  <RotateCcw className="w-4 h-4 mr-2" />
                                  {historyEntry?.renewalCount >= 3 ? 'Max Renewals' : 'Renew'}
                                </Button>
                                
                                <Button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    startReadingSession(book.id);
                                  }}
                                  variant="outline"
                                  className="border-white/20 text-white hover:bg-white/10 rounded-xl transition-all duration-300"
                                >
                                  <Eye className="w-4 h-4 mr-2" />
                                  Read Now
                                </Button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div 
                    className="p-12 text-center backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                    style={{
                      backdropFilter: 'blur(20px) saturate(180%)',
                      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                    }}
                  >
                    <BookOpen className="w-16 h-16 text-white/40 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white mb-2">No books currently borrowed</h3>
                    <p className="text-white/60">Browse our library to find your next great read!</p>
                  </div>
                )}
              </motion.section>

              {/* Reserved Books */}
              {reservedBooks.length > 0 && (
                <motion.section
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent mb-4">
                    Reserved Books ({reservedBooks.length})
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {reservedBooks.map((bookId, index) => {
                      const book = allBooks.find(b => b.id === bookId);
                      if (!book) return null;
                      
                      return (
                        <motion.div
                          key={bookId}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                        >
                          <div 
                            className="p-4 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl transition-all duration-300 hover:bg-white/[0.12]"
                            style={{
                              backdropFilter: 'blur(20px) saturate(180%)',
                              WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                            }}
                          >
                            <div className="flex items-center space-x-4">
                              <ImageWithFallback
                                src={book.coverUrl}
                                alt={book.title}
                                className="w-16 h-20 object-cover rounded-lg"
                              />
                              <div className="flex-1">
                                <h4 className="font-medium text-white">{book.title}</h4>
                                <p className="text-white/70 text-sm">{book.author}</p>
                                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 mt-2 text-xs">
                                  <MapPin className="w-3 h-3 mr-1" />
                                  Reserved
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </motion.section>
              )}
            </TabsContent>

            <TabsContent value="history" className="space-y-6">
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
              >
                <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent mb-6">
                  Reading History ({borrowHistory.length})
                </h2>

                <div className="space-y-4">
                  {borrowHistory.map((entry, index) => (
                    <motion.div
                      key={entry.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                    >
                      <div 
                        className="p-6 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl transition-all duration-300 hover:bg-white/[0.12]"
                        style={{
                          backdropFilter: 'blur(20px) saturate(180%)',
                          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                        }}
                      >
                        <div className="flex items-center space-x-6">
                          <ImageWithFallback
                            src={entry.book.coverUrl}
                            alt={entry.book.title}
                            className="w-20 h-28 object-cover rounded-xl shadow-lg"
                          />
                          <div className="flex-1">
                            <h3 className="text-xl font-bold text-white mb-1">{entry.book.title}</h3>
                            <p className="text-white/70 mb-3">by {entry.book.author}</p>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                              <div>
                                <p className="text-white/60 text-sm">Borrowed</p>
                                <p className="text-white font-medium">{new Date(entry.borrowDate).toLocaleDateString()}</p>
                              </div>
                              {entry.returnDate && (
                                <div>
                                  <p className="text-white/60 text-sm">Returned</p>
                                  <p className="text-white font-medium">{new Date(entry.returnDate).toLocaleDateString()}</p>
                                </div>
                              )}
                              <div>
                                <p className="text-white/60 text-sm">Status</p>
                                <Badge className={`${
                                  entry.status === 'returned' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                                  entry.status === 'current' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                                  'bg-red-500/20 text-red-400 border-red-500/30'
                                }`}>
                                  {entry.status}
                                </Badge>
                              </div>
                            </div>

                            {entry.rating ? (
                              <div className="flex items-center space-x-4">
                                <div className="flex items-center space-x-1">
                                  <span className="text-white/70 text-sm">Your rating:</span>
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`w-4 h-4 ${
                                        star <= entry.rating! ? 'text-yellow-400 fill-current' : 'text-white/30'
                                      }`}
                                    />
                                  ))}
                                </div>
                                {entry.review && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-white/60 hover:text-white transition-all duration-300"
                                    onClick={() => {
                                      toast.info(entry.review!);
                                    }}
                                  >
                                    <MessageCircle className="w-4 h-4 mr-1" />
                                    View Review
                                  </Button>
                                )}
                              </div>
                            ) : entry.status === 'returned' && (
                              <div className="flex items-center space-x-2">
                                <span className="text-white/70 text-sm">Rate this book:</span>
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Button
                                    key={star}
                                    variant="ghost"
                                    size="sm"
                                    className="p-1 text-white/40 hover:text-yellow-400 transition-all duration-300"
                                    onClick={() => handleRateBook(entry.book.id, star)}
                                  >
                                    <Star className="w-4 h-4" />
                                  </Button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.section>
            </TabsContent>

            <TabsContent value="ebooks" className="space-y-6">
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
                    Digital Library ({eBooks.length})
                  </h2>
                  <Badge className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border border-purple-500/30">
                    <FileText className="w-4 h-4 mr-1" />
                    eBooks & Audiobooks
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {eBooks.map((ebook, index) => (
                    <motion.div
                      key={ebook.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                    >
                      <div 
                        className="p-6 cursor-pointer backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:bg-white/[0.12]" 
                        onClick={() => {
                          if (currentlyReading === ebook.id) {
                            setCurrentlyReading(null);
                            toast.info('Reading session paused');
                          } else {
                            startReadingSession(ebook.id);
                            toast.success(`Started reading "${ebook.title}"`);
                          }
                        }}
                        style={{
                          backdropFilter: 'blur(20px) saturate(180%)',
                          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                        }}
                      >
                        <div className="flex items-start space-x-4 mb-4">
                          <ImageWithFallback
                            src={ebook.coverUrl}
                            alt={ebook.title}
                            className="w-20 h-28 object-cover rounded-xl shadow-lg"
                          />
                          <div className="flex-1">
                            <h3 className="font-bold text-white mb-1">{ebook.title}</h3>
                            <p className="text-white/70 text-sm mb-2">{ebook.author}</p>
                            <div className="flex items-center space-x-2 mb-2">
                              <Star className="w-4 h-4 text-yellow-400 fill-current" />
                              <span className="text-white/80 text-sm">{ebook.rating}</span>
                              <Badge className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30 text-xs">
                                {ebook.category}
                              </Badge>
                            </div>
                            <p className="text-white/60 text-xs">{ebook.totalPages} pages</p>
                          </div>
                        </div>

                        {/* Reading Progress */}
                        <div className="mb-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white/70 text-sm">Reading Progress</span>
                            <span className="text-white/70 text-sm">{ebook.readingProgress}%</span>
                          </div>
                          <Progress value={ebook.readingProgress} className="h-2" />
                          {ebook.lastRead && (
                            <p className="text-white/50 text-xs mt-1">
                              Last read: {new Date(ebook.lastRead).toLocaleDateString()}
                            </p>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (currentlyReading === ebook.id) {
                                setCurrentlyReading(null);
                                toast.info('Reading session ended');
                              } else {
                                startReadingSession(ebook.id);
                              }
                            }}
                            className={`flex-1 rounded-xl transition-all duration-300 ${
                              currentlyReading === ebook.id
                                ? 'bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700'
                                : 'bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700'
                            }`}
                            size="sm"
                          >
                            {currentlyReading === ebook.id ? (
                              <>
                                <Pause className="w-4 h-4 mr-1" />
                                Reading...
                              </>
                            ) : (
                              <>
                                <Play className="w-4 h-4 mr-1" />
                                Read
                              </>
                            )}
                          </Button>

                          {ebook.audioUrl && (
                            <Button
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleAudioPlayback(ebook.id);
                              }}
                              variant="outline"
                              className="border-white/20 text-white hover:bg-white/10 rounded-xl transition-all duration-300"
                              size="sm"
                            >
                              {audioPlaying === ebook.id ? (
                                <VolumeX className="w-4 h-4" />
                              ) : (
                                <Volume2 className="w-4 h-4" />
                              )}
                            </Button>
                          )}

                          {ebook.downloadable && (
                            <Button
                              onClick={(e) => {
                                e.stopPropagation();
                                toast.success(`"${ebook.title}" download started`);
                              }}
                              variant="outline"
                              className="border-white/20 text-white hover:bg-white/10 rounded-xl transition-all duration-300"
                              size="sm"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.section>
            </TabsContent>

            <TabsContent value="wishlist" className="space-y-6">
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
              >
                <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent mb-6">
                  Your Wishlist ({wishlist.length})
                </h2>

                {wishlist.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {wishlist.map((bookId, index) => {
                      const book = allBooks.find(b => b.id === bookId);
                      if (!book) return null;
                      
                      return (
                        <motion.div
                          key={bookId}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                        >
                          <div className="relative">
                            <BookCard
                              book={book}
                              onClick={handleBookClick}
                              size="medium"
                            />
                            <motion.button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleWishlistToggle(bookId);
                              }}
                              className="absolute top-2 right-2 p-2 bg-red-500/80 rounded-full backdrop-blur-xl text-white hover:bg-red-600/80 transition-all duration-300 shadow-lg"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.95 }}
                              style={{
                                backdropFilter: 'blur(10px)',
                                WebkitBackdropFilter: 'blur(10px)',
                              }}
                            >
                              <Heart className="w-4 h-4 fill-current" />
                            </motion.button>
                            
                            {/* Quick Action Buttons */}
                            <motion.div
                              className="absolute bottom-2 left-2 right-2 flex space-x-2"
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 + 0.2 }}
                            >
                              <Button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (book.status === 'available') {
                                    handleBorrowBook(book);
                                  } else {
                                    handleReserveBook(book);
                                  }
                                }}
                                className="flex-1 bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 rounded-xl text-xs transition-all duration-300"
                                size="sm"
                              >
                                {book.status === 'available' ? 'Borrow' : 'Reserve'}
                              </Button>
                            </motion.div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div 
                    className="p-12 text-center backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                    style={{
                      backdropFilter: 'blur(20px) saturate(180%)',
                      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                    }}
                  >
                    <Heart className="w-16 h-16 text-white/40 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white mb-2">Your wishlist is empty</h3>
                    <p className="text-white/60 mb-4">Add books you're interested in to keep track of them!</p>
                    <Button 
                      onClick={() => setActiveTab('browse')}
                      className="bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 rounded-xl transition-all duration-300"
                    >
                      Browse Books
                    </Button>
                  </div>
                )}
              </motion.section>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <motion.section
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
              >
                <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent mb-6">
                  Reading Analytics
                </h2>

                {/* Reading Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  {[
                    { icon: BookOpen, value: totalBooksRead, label: 'Books Completed', color: 'text-indigo-400' },
                    { icon: Clock, value: `${Math.round(totalReadingTime / (1000 * 60 * 60))}h`, label: 'Reading Time', color: 'text-green-400' },
                    { icon: Star, value: averageRating.toFixed(1), label: 'Average Rating', color: 'text-yellow-400' },
                    { icon: TrendingUp, value: (Math.round((totalBooksRead / 12) * 10) / 10), label: 'Books/Month', color: 'text-purple-400' }
                  ].map((stat, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 25 }}
                    >
                      <div 
                        className="p-6 text-center backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl transition-all duration-300 hover:bg-white/[0.12]"
                        style={{
                          backdropFilter: 'blur(20px) saturate(180%)',
                          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                        }}
                      >
                        <stat.icon className={`w-12 h-12 ${stat.color} mx-auto mb-4`} />
                        <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                        <div className="text-white/70">{stat.label}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Reading Goals */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <div 
                    className="p-6 mb-6 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                    style={{
                      backdropFilter: 'blur(20px) saturate(180%)',
                      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                    }}
                  >
                    <h3 className="text-xl font-bold text-white mb-4">Reading Goals</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-white/70">Annual Reading Goal</span>
                          <span className="text-white">{totalBooksRead}/50 books</span>
                        </div>
                        <Progress value={(totalBooksRead / 50) * 100} className="h-3" />
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-white/70">Monthly Reading Goal</span>
                          <span className="text-white">3/4 books</span>
                        </div>
                        <Progress value={75} className="h-3" />
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Favorite Categories */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <div 
                    className="p-6 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                    style={{
                      backdropFilter: 'blur(20px) saturate(180%)',
                      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                    }}
                  >
                    <h3 className="text-xl font-bold text-white mb-4">Favorite Categories</h3>
                    <div className="space-y-3">
                      {['Technology', 'Science', 'Fiction', 'Business'].map((category, index) => (
                        <div key={category} className="flex items-center justify-between">
                          <span className="text-white/70">{category}</span>
                          <div className="flex items-center space-x-3">
                            <div className="w-32 bg-white/10 rounded-full h-2">
                              <div 
                                className="bg-gradient-to-r from-indigo-500 to-blue-500 h-2 rounded-full transition-all duration-1000"
                                style={{ width: `${(4 - index) * 25}%` }}
                              />
                            </div>
                            <span className="text-white text-sm">{4 - index} books</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </motion.section>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>

      {/* Enhanced Book Details Modal */}
      <AnimatePresence>
        {showBookDetails && (
          <div 
            className="fixed inset-0 bg-black/70 backdrop-blur-md z-[500] flex items-center justify-center p-6"
            style={{
              backdropFilter: 'blur(30px) saturate(180%)',
              WebkitBackdropFilter: 'blur(30px) saturate(180%)',
            }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div 
                className="p-8 backdrop-blur-3xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-2xl"
                style={{
                  backdropFilter: 'blur(40px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                }}
              >
                <div className="flex justify-between items-start mb-8">
                  <h2 className="text-4xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
                    {showBookDetails.title}
                  </h2>
                  <motion.button
                    onClick={() => setShowBookDetails(null)}
                    className="text-white/70 hover:text-white text-3xl p-2 rounded-full hover:bg-white/10 transition-all duration-300"
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    ×
                  </motion.button>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div>
                    <ImageWithFallback
                      src={showBookDetails.coverUrl}
                      alt={showBookDetails.title}
                      className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                    />
                    
                    {/* Book Stats */}
                    <div className="mt-6 grid grid-cols-2 gap-4">
                      <div 
                        className="p-4 text-center backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                        style={{
                          backdropFilter: 'blur(20px) saturate(180%)',
                          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                        }}
                      >
                        <Star className="w-6 h-6 text-yellow-400 mx-auto mb-2 fill-current" />
                        <div className="text-white font-bold">{showBookDetails.rating}</div>
                        <div className="text-white/60 text-sm">Rating</div>
                      </div>
                      <div 
                        className="p-4 text-center backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
                        style={{
                          backdropFilter: 'blur(20px) saturate(180%)',
                          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                        }}
                      >
                        <Eye className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                        <div className="text-white font-bold">1.2k</div>
                        <div className="text-white/60 text-sm">Views</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <p className="text-white/70 mb-1">Author</p>
                      <p className="text-xl font-bold text-white">{showBookDetails.author}</p>
                    </div>
                    
                    <div>
                      <p className="text-white/70 mb-1">Description</p>
                      <p className="text-white/90 leading-relaxed">{showBookDetails.description}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-white/70 mb-1">Category</p>
                        <Badge className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30">
                          {showBookDetails.category}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-white/70 mb-1">Status</p>
                        <Badge className={`${
                          showBookDetails.status === 'available' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                          showBookDetails.status === 'borrowed' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                          'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                        }`}>
                          {showBookDetails.status}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex space-x-4 pt-4">
                      <Button 
                        onClick={() => handleBorrowBook(showBookDetails)}
                        className="flex-1 h-12 bg-gradient-to-r from-indigo-500 via-blue-500 to-purple-500 hover:from-indigo-600 hover:via-blue-600 hover:to-purple-600 rounded-2xl font-medium transition-all duration-300"
                      >
                        {showBookDetails.status === 'available' ? (
                          <>
                            <BookOpen className="w-5 h-5 mr-2" />
                            Borrow Book
                          </>
                        ) : (
                          <>
                            <Bookmark className="w-5 h-5 mr-2" />
                            Reserve Book
                          </>
                        )}
                      </Button>
                      
                      <Button 
                        onClick={() => handleWishlistToggle(showBookDetails.id)}
                        variant="outline" 
                        className={`border-white/20 rounded-2xl h-12 px-6 transition-all duration-300 ${
                          wishlist.includes(showBookDetails.id) 
                            ? 'bg-red-500/20 text-red-400 border-red-500/30' 
                            : 'text-white hover:bg-white/10'
                        }`}
                      >
                        <Heart className={`w-5 h-5 mr-2 ${wishlist.includes(showBookDetails.id) ? 'fill-current' : ''}`} />
                        {wishlist.includes(showBookDetails.id) ? 'Remove' : 'Wishlist'}
                      </Button>
                      
                      <Button 
                        variant="outline"
                        className="border-white/20 text-white hover:bg-white/10 rounded-2xl h-12 px-6 transition-all duration-300"
                      >
                        <Share2 className="w-5 h-5 mr-2" />
                        Share
                      </Button>
                    </div>

                    {/* Quick Actions */}
                    <div className="flex space-x-2 pt-2">
                      <Button 
                        variant="ghost"
                        size="sm"
                        className="text-white/60 hover:text-white transition-all duration-300"
                      >
                        <ThumbsUp className="w-4 h-4 mr-1" />
                        Like
                      </Button>
                      <Button 
                        variant="ghost"
                        size="sm"
                        className="text-white/60 hover:text-white transition-all duration-300"
                      >
                        <MessageCircle className="w-4 h-4 mr-1" />
                        Review
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Enhanced Payment System Modal */}
      <AnimatePresence>
        {showPaymentSystem && (
          <div 
            className="fixed inset-0 bg-black/70 backdrop-blur-md z-[600] flex items-center justify-center p-6"
            style={{
              backdropFilter: 'blur(30px) saturate(180%)',
              WebkitBackdropFilter: 'blur(30px) saturate(180%)',
            }}
          >
            <PaymentSystem 
              onClose={() => setShowPaymentSystem(false)}
              userRole="student"
            />
          </div>
        )}
      </AnimatePresence>

      {/* Enhanced Reading Session Timer */}
      <AnimatePresence>
        {currentlyReading && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="fixed bottom-6 right-6 z-[400]"
          >
            <div 
              className="p-4 min-w-[300px] backdrop-blur-3xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-2xl"
              style={{
                backdropFilter: 'blur(30px) saturate(180%)',
                WebkitBackdropFilter: 'blur(30px) saturate(180%)',
              }}
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-white">Reading Session</h4>
                <Button
                  onClick={() => {
                    const pagesRead = Math.floor(Math.random() * 20) + 5; // Simulate pages read
                    endReadingSession(pagesRead);
                  }}
                  variant="ghost"
                  size="sm"
                  className="text-white/60 hover:text-white p-1 transition-all duration-300"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex items-center space-x-3">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Clock className="w-5 h-5 text-indigo-400" />
                </motion.div>
                <div className="flex-1">
                  <p className="text-white text-sm">Currently reading</p>
                  <p className="text-white/70 text-xs">
                    {allBooks.find(b => b.id === currentlyReading)?.title}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}