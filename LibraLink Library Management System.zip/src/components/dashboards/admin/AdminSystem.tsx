import React from 'react';
import { Database, Server, HardDrive, Cpu, RefreshCw, Download } from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';
import { Badge } from '../../ui/badge';

const systemMetrics = [
  { name: 'CPU Usage', value: '45%', status: 'normal', icon: Cpu },
  { name: 'Memory Usage', value: '68%', status: 'normal', icon: HardDrive },
  { name: 'Disk Space', value: '82%', status: 'warning', icon: Database },
  { name: 'Network', value: '23%', status: 'normal', icon: Server }
];

const backupHistory = [
  { date: '2024-01-15', status: 'completed', size: '2.3 GB' },
  { date: '2024-01-14', status: 'completed', size: '2.2 GB' },
  { date: '2024-01-13', status: 'failed', size: '-' },
  { date: '2024-01-12', status: 'completed', size: '2.1 GB' }
];

export default function AdminSystem() {
  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white">System Management</h3>

      {/* System Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {systemMetrics.map((metric) => (
          <GlassCard key={metric.name} className="p-6 text-center">
            <metric.icon className={`w-8 h-8 mx-auto mb-2 ${
              metric.status === 'warning' ? 'text-yellow-400' : 'text-green-400'
            }`} />
            <div className="text-2xl font-bold text-white">{metric.value}</div>
            <div className="text-white/70">{metric.name}</div>
            <Badge className={`mt-2 ${
              metric.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'
            }`}>
              {metric.status}
            </Badge>
          </GlassCard>
        ))}
      </div>

      {/* System Actions */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-bold text-white mb-4">System Actions</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button className="h-16 bg-gradient-to-r from-blue-500 to-indigo-600">
            <RefreshCw className="w-5 h-5 mr-2" />
            System Restart
          </Button>
          <Button className="h-16 bg-gradient-to-r from-green-500 to-emerald-600">
            <Database className="w-5 h-5 mr-2" />
            Create Backup
          </Button>
          <Button className="h-16 bg-gradient-to-r from-purple-500 to-pink-600">
            <Download className="w-5 h-5 mr-2" />
            Export Data
          </Button>
        </div>
      </GlassCard>

      {/* Backup History */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-bold text-white mb-4">Backup History</h4>
        <div className="space-y-3">
          {backupHistory.map((backup, index) => (
            <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
              <div>
                <span className="text-white font-medium">{backup.date}</span>
                <span className="text-white/70 ml-4">{backup.size}</span>
              </div>
              <Badge className={`${
                backup.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
              }`}>
                {backup.status}
              </Badge>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}