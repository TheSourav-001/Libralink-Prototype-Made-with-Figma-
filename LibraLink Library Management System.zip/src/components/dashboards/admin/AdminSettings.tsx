import React from 'react';
import { Settings, Shield, Bell, Database, Globe } from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';
import { Switch } from '../../ui/switch';

const settingsGroups = [
  {
    title: 'General Settings',
    icon: Settings,
    settings: [
      { name: 'Maintenance Mode', description: 'Enable system maintenance mode', enabled: false },
      { name: 'New User Registration', description: 'Allow new users to register', enabled: true },
      { name: 'Email Notifications', description: 'Send system email notifications', enabled: true }
    ]
  },
  {
    title: 'Security Settings',
    icon: Shield,
    settings: [
      { name: 'Two-Factor Authentication', description: 'Require 2FA for all users', enabled: false },
      { name: 'Password Complexity', description: 'Enforce strong password requirements', enabled: true },
      { name: 'Session Timeout', description: 'Auto-logout inactive users', enabled: true }
    ]
  },
  {
    title: 'Notification Settings',
    icon: Bell,
    settings: [
      { name: 'Overdue Notifications', description: 'Send overdue book reminders', enabled: true },
      { name: 'System Alerts', description: 'Send system status alerts', enabled: true },
      { name: 'Weekly Reports', description: 'Send weekly activity reports', enabled: false }
    ]
  }
];

export default function AdminSettings() {
  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white">System Settings</h3>

      {settingsGroups.map((group) => (
        <GlassCard key={group.title} className="p-6">
          <div className="flex items-center space-x-2 mb-4">
            <group.icon className="w-6 h-6 text-red-400" />
            <h4 className="text-lg font-bold text-white">{group.title}</h4>
          </div>
          
          <div className="space-y-4">
            {group.settings.map((setting) => (
              <div key={setting.name} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                <div>
                  <h5 className="font-medium text-white">{setting.name}</h5>
                  <p className="text-white/70 text-sm">{setting.description}</p>
                </div>
                <Switch defaultChecked={setting.enabled} />
              </div>
            ))}
          </div>
        </GlassCard>
      ))}

      <GlassCard className="p-6">
        <h4 className="text-lg font-bold text-white mb-4">Danger Zone</h4>
        <div className="space-y-4">
          <Button variant="outline" className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10">
            <Database className="w-4 h-4 mr-2" />
            Reset All Data
          </Button>
          <Button variant="outline" className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10">
            <Globe className="w-4 h-4 mr-2" />
            Factory Reset
          </Button>
        </div>
      </GlassCard>
    </div>
  );
}