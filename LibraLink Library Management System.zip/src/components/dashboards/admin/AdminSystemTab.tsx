import React from 'react';
import { Server, Activity, AlertTriangle } from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';
import { Badge } from '../../ui/badge';
import { systemMetrics } from '../../../data/adminConstants';

interface AdminSystemTabProps {
  onSystemAction: (action: string) => void;
}

export default function AdminSystemTab({ onSystemAction }: AdminSystemTabProps) {
  return (
    <div className="space-y-8">
      <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent">
        System Health Monitor
      </h3>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {systemMetrics.map((metric, index) => (
          <GlassCard key={metric.name} className="p-6">
            <div className="flex items-center justify-between mb-4">
              <metric.icon className="w-8 h-8 text-white/80" />
              <Badge className={`${
                metric.status === 'good' ? 'bg-green-500/20 text-green-400' :
                metric.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                'bg-red-500/20 text-red-400'
              }`}>
                {metric.status}
              </Badge>
            </div>
            <div className="text-2xl font-bold text-white mb-2">{metric.value}</div>
            <div className="text-white/70">{metric.name}</div>
          </GlassCard>
        ))}
      </div>

      {/* System Controls */}
      <GlassCard className="p-6">
        <h4 className="text-xl font-bold text-white mb-6">System Controls</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            onClick={() => onSystemAction('Restart Services')}
            className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 rounded-2xl"
          >
            <Server className="w-4 h-4 mr-2" />
            Restart Services
          </Button>
          <Button 
            onClick={() => onSystemAction('Update System')}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-2xl"
          >
            <Activity className="w-4 h-4 mr-2" />
            Update System
          </Button>
          <Button 
            onClick={() => onSystemAction('Emergency Shutdown')}
            className="bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 rounded-2xl"
          >
            <AlertTriangle className="w-4 h-4 mr-2" />
            Emergency Shutdown
          </Button>
        </div>
      </GlassCard>
    </div>
  );
}