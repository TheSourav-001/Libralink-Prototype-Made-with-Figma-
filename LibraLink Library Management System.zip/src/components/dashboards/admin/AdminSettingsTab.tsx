import React from 'react';
import { Lock, Settings } from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';

interface AdminSettingsTabProps {
  onSystemAction: (action: string) => void;
}

export default function AdminSettingsTab({ onSystemAction }: AdminSettingsTabProps) {
  return (
    <div className="space-y-8">
      <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent">
        System Settings
      </h3>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassCard className="p-6">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center">
            <Lock className="w-6 h-6 mr-2 text-red-400" />
            Security Settings
          </h4>
          <div className="space-y-4">
            <Button 
              onClick={() => onSystemAction('Change Admin Password')}
              className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 rounded-2xl"
            >
              Change Admin Password
            </Button>
            <Button 
              onClick={() => onSystemAction('Configure 2FA')}
              variant="outline" 
              className="w-full border-white/20 text-white hover:bg-white/10 rounded-2xl"
            >
              Configure 2FA
            </Button>
            <Button 
              onClick={() => onSystemAction('Security Audit')}
              variant="outline" 
              className="w-full border-white/20 text-white hover:bg-white/10 rounded-2xl"
            >
              Run Security Audit
            </Button>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center">
            <Settings className="w-6 h-6 mr-2 text-blue-400" />
            System Configuration
          </h4>
          <div className="space-y-4">
            <Button 
              onClick={() => onSystemAction('Update Configuration')}
              className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-2xl"
            >
              Update Configuration
            </Button>
            <Button 
              onClick={() => onSystemAction('Manage Permissions')}
              variant="outline" 
              className="w-full border-white/20 text-white hover:bg-white/10 rounded-2xl"
            >
              Manage Permissions
            </Button>
            <Button 
              onClick={() => onSystemAction('Export Logs')}
              variant="outline" 
              className="w-full border-white/20 text-white hover:bg-white/10 rounded-2xl"
            >
              Export System Logs
            </Button>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}