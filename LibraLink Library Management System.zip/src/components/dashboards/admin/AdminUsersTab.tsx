import React from 'react';
import { Users, Shield, Activity, UserX } from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';
import { userStats } from '../../../data/adminConstants';

interface AdminUsersTabProps {
  onUserAction: (action: string, userId?: string) => void;
}

export default function AdminUsersTab({ onUserAction }: AdminUsersTabProps) {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent">
          User Management
        </h3>
      </div>

      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <GlassCard className="p-6 text-center">
          <Users className="w-12 h-12 text-blue-400 mx-auto mb-4" />
          <div className="text-3xl font-bold text-white mb-2">{userStats.students}</div>
          <div className="text-white/70">Students</div>
        </GlassCard>
        <GlassCard className="p-6 text-center">
          <Shield className="w-12 h-12 text-green-400 mx-auto mb-4" />
          <div className="text-3xl font-bold text-white mb-2">{userStats.faculty}</div>
          <div className="text-white/70">Faculty</div>
        </GlassCard>
        <GlassCard className="p-6 text-center">
          <Activity className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <div className="text-3xl font-bold text-white mb-2">{userStats.activeUsers}</div>
          <div className="text-white/70">Active Users</div>
        </GlassCard>
        <GlassCard className="p-6 text-center">
          <UserX className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <div className="text-3xl font-bold text-white mb-2">{userStats.bannedUsers}</div>
          <div className="text-white/70">Banned Users</div>
        </GlassCard>
      </div>

      {/* User Actions */}
      <GlassCard className="p-6">
        <h4 className="text-xl font-bold text-white mb-4">User Actions</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            onClick={() => onUserAction('Create New User')}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-2xl"
          >
            Create New User
          </Button>
          <Button 
            onClick={() => onUserAction('Export User Data')}
            variant="outline" 
            className="border-white/20 text-white hover:bg-white/10 rounded-2xl"
          >
            Export User Data
          </Button>
          <Button 
            onClick={() => onUserAction('Bulk Operations')}
            variant="outline" 
            className="border-white/20 text-white hover:bg-white/10 rounded-2xl"
          >
            Bulk Operations
          </Button>
        </div>
      </GlassCard>

      {/* Recent User Activity */}
      <GlassCard className="p-6">
        <h4 className="text-xl font-bold text-white mb-4">Recent User Activity</h4>
        <div className="space-y-4">
          {['John Smith registered as Student', 'Dr. Wilson updated profile', 'Alice Johnson changed password', 'System Admin logged in'].map((activity, index) => (
            <div key={index} className="flex items-center justify-between p-4 rounded-xl bg-white/5">
              <span className="text-white">{activity}</span>
              <span className="text-white/60 text-sm">{index + 1} hour{index !== 0 ? 's' : ''} ago</span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}