import React from 'react';
import { TrendingUp, Users, BookOpen, DollarSign } from 'lucide-react';
import GlassCard from '../../GlassCard';
import { analyticsData } from '../../../data/adminData';

export default function AdminAnalytics() {
  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white">Analytics Dashboard</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <GlassCard className="p-6">
          <h4 className="text-lg font-bold text-white mb-4">Popular Categories</h4>
          <div className="space-y-3">
            {analyticsData.popularCategories.map((category) => (
              <div key={category.name} className="flex items-center justify-between">
                <span className="text-white/80">{category.name}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-red-400 to-pink-500 rounded-full"
                      style={{ width: `${category.percentage}%` }}
                    />
                  </div>
                  <span className="text-white/60 text-sm">{category.percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h4 className="text-lg font-bold text-white mb-4">User Activity</h4>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-white/80">Active Students</span>
              <span className="text-white font-medium">{analyticsData.userActivity.activeStudents}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/80">Active Faculty</span>
              <span className="text-white font-medium">{analyticsData.userActivity.activeFaculty}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/80">Books Borrowed Today</span>
              <span className="text-white font-medium">{analyticsData.userActivity.booksBorrowedToday}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/80">Overdue Books</span>
              <span className="text-red-400 font-medium">{analyticsData.userActivity.overdueBooks}</span>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}