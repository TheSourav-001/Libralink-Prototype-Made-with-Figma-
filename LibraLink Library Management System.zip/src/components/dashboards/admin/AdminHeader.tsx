import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, AlertTriangle, LogOut } from 'lucide-react';
import { Button } from '../../ui/button';
import { User } from '../../../App';
import { adminStats } from '../../../data/adminData';

interface AdminHeaderProps {
  user: User;
  onBack: () => void;
  onLogout: () => void;
}

export default function AdminHeader({ user, onBack, onLogout }: AdminHeaderProps) {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="backdrop-blur-xl bg-red-500/10 border-b border-white/10 p-4"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center space-x-4">
          <motion.button
            onClick={onBack}
            className="p-2 rounded-full backdrop-blur-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-300"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5" />
          </motion.button>
          
          <div>
            <h1 className="text-2xl font-bold text-white">System Administration</h1>
            <p className="text-white/70">Admin Dashboard - {user.name}</p>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* System Status */}
          <div className="flex items-center space-x-2 px-3 py-2 rounded-full backdrop-blur-xl bg-white/10 border border-white/20">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-white text-sm">System Online</span>
          </div>

          {/* Alerts */}
          <motion.button
            className="relative p-2 rounded-full backdrop-blur-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-300"
            whileHover={{ scale: 1.1 }}
          >
            <AlertTriangle className="w-5 h-5" />
            {adminStats.systemAlerts > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
                {adminStats.systemAlerts}
              </span>
            )}
          </motion.button>

          {/* Logout */}
          <Button
            onClick={onLogout}
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </motion.header>
  );
}