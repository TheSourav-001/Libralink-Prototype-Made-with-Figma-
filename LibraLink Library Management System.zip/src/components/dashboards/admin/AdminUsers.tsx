import React from 'react';
import { Users, UserPlus, Shield, Edit, Trash2 } from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';
import { Badge } from '../../ui/badge';
import { userStats } from '../../../data/adminData';

const mockUsers = [
  { id: '1', name: 'John Smith', email: 'john@university.edu', role: 'student', status: 'active', lastActive: '2 hours ago' },
  { id: '2', name: 'Dr. Jane Wilson', email: 'jane.wilson@university.edu', role: 'faculty', status: 'active', lastActive: '1 hour ago' },
  { id: '3', name: 'Alice Johnson', email: 'alice@university.edu', role: 'student', status: 'inactive', lastActive: '2 days ago' },
  { id: '4', name: 'Bob Brown', email: 'bob.brown@university.edu', role: 'librarian', status: 'active', lastActive: '30 minutes ago' }
];

export default function AdminUsers() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-white">User Management</h3>
        <Button className="bg-gradient-to-r from-red-500 to-pink-600">
          <UserPlus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {userStats.map((stat) => (
          <GlassCard key={stat.role} className="p-4 text-center">
            <Users className={`w-6 h-6 text-${stat.color}-400 mx-auto mb-2`} />
            <div className="text-lg font-bold text-white">{stat.count}</div>
            <div className="text-white/70 text-sm">{stat.role}</div>
          </GlassCard>
        ))}
      </div>

      {/* Users Table */}
      <GlassCard className="p-6">
        <div className="space-y-4">
          {mockUsers.map((user) => (
            <div key={user.id} className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-red-500 to-pink-600 flex items-center justify-center">
                  <span className="text-white font-medium">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <h4 className="font-medium text-white">{user.name}</h4>
                  <p className="text-white/70 text-sm">{user.email}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Badge className={`${
                  user.role === 'admin' ? 'bg-red-500/20 text-red-400' :
                  user.role === 'librarian' ? 'bg-green-500/20 text-green-400' :
                  user.role === 'faculty' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}>
                  {user.role}
                </Badge>
                
                <Badge className={`${
                  user.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                }`}>
                  {user.status}
                </Badge>
                
                <span className="text-white/60 text-sm">{user.lastActive}</span>
                
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="border-white/20 text-white">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="border-red-500/50 text-red-400">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}