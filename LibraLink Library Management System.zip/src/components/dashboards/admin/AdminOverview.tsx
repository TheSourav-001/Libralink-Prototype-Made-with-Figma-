import React from 'react';
import { Users, BarChart3, DollarSign, BookOpen, Bell, TrendingUp, AlertTriangle } from 'lucide-react';
import GlassCard from '../../GlassCard';
import { Badge } from '../../ui/badge';
import { adminStats, userStats, recentActivities, systemAlerts } from '../../../data/adminData';

const getActivityIcon = (type: string) => {
  switch (type) {
    case 'user': return Users;
    case 'book': return BookOpen;
    case 'system': return BarChart3;
    case 'payment': return DollarSign;
    case 'security': return AlertTriangle;
    default: return Bell;
  }
};

const getAlertColor = (level: string) => {
  switch (level) {
    case 'error': return 'bg-red-500/20 text-red-400';
    case 'warning': return 'bg-yellow-500/20 text-yellow-400';
    case 'info': return 'bg-blue-500/20 text-blue-400';
    default: return 'bg-gray-500/20 text-gray-400';
  }
};

export default function AdminOverview() {
  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard accent="red" className="p-6 text-center">
          <Users className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{adminStats.totalUsers.toLocaleString()}</div>
          <div className="text-white/70">Total Users</div>
        </GlassCard>
        
        <GlassCard accent="green" className="p-6 text-center">
          <BookOpen className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{adminStats.totalBooks}</div>
          <div className="text-white/70">Total Books</div>
        </GlassCard>
        
        <GlassCard accent="amber" className="p-6 text-center">
          <DollarSign className="w-8 h-8 text-amber-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">${adminStats.totalRevenue.toLocaleString()}</div>
          <div className="text-white/70">Revenue</div>
        </GlassCard>
        
        <GlassCard accent="purple" className="p-6 text-center">
          <TrendingUp className="w-8 h-8 text-purple-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{adminStats.systemUptime}</div>
          <div className="text-white/70">Uptime</div>
        </GlassCard>
      </div>

      {/* User Statistics */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-bold text-white mb-6">User Statistics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {userStats.map((stat) => (
            <div key={stat.role} className="text-center p-4 rounded-xl bg-white/5">
              <div className="text-lg font-bold text-white">{stat.count.toLocaleString()}</div>
              <div className="text-white/70 text-sm">{stat.role}</div>
              <Badge className={`mt-2 text-xs bg-${stat.color}-500/20 text-${stat.color}-400`}>
                {stat.growth}
              </Badge>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Recent Activity & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassCard className="p-6">
          <h3 className="text-xl font-bold text-white mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => {
              const ActivityIcon = getActivityIcon(activity.type);
              return (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-xl bg-white/5">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-red-500 to-pink-600 flex items-center justify-center">
                    <ActivityIcon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium text-sm">{activity.action}</p>
                    <p className="text-white/70 text-xs">{activity.user} • {activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="text-xl font-bold text-white mb-4">System Alerts</h3>
          <div className="space-y-3">
            {systemAlerts.map((alert, index) => (
              <div key={index} className="p-3 rounded-xl bg-white/5">
                <div className="flex items-center justify-between mb-2">
                  <Badge className={getAlertColor(alert.level)}>
                    {alert.level.toUpperCase()}
                  </Badge>
                  <span className="text-white/60 text-xs">{alert.time}</span>
                </div>
                <p className="text-white/90 text-sm">{alert.message}</p>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}