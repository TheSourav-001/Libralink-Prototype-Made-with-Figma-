import React from 'react';
import { motion } from 'motion/react';
import { BarChart3, Users, Database, TrendingUp, Settings } from 'lucide-react';
import { AdminTab } from '../AdminDashboard';
import { adminStats } from '../../../data/adminData';
import { Badge } from '../../ui/badge';

interface AdminTabsProps {
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
}

const tabs = [
  { id: 'overview' as AdminTab, label: 'Overview', icon: BarChart3 },
  { id: 'users' as AdminTab, label: 'Users', icon: Users },
  { id: 'system' as AdminTab, label: 'System', icon: Database },
  { id: 'analytics' as AdminTab, label: 'Analytics', icon: TrendingUp },
  { id: 'settings' as AdminTab, label: 'Settings', icon: Settings }
];

export default function AdminTabs({ activeTab, onTabChange }: AdminTabsProps) {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="flex space-x-4 mb-8 overflow-x-auto"
    >
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
            activeTab === tab.id
              ? 'bg-gradient-to-r from-red-500 to-pink-600 text-white shadow-lg'
              : 'bg-white/10 text-white/70 hover:bg-white/20'
          }`}
        >
          <tab.icon className="w-5 h-5" />
          <span>{tab.label}</span>
          {tab.id === 'system' && adminStats.systemAlerts > 0 && (
            <Badge className="bg-red-500 text-white text-xs">
              {adminStats.systemAlerts}
            </Badge>
          )}
        </button>
      ))}
    </motion.div>
  );
}