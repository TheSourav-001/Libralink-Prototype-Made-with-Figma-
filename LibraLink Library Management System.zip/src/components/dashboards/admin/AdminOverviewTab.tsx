import React from 'react';
import { motion } from 'motion/react';
import { 
  AlertTriangle,
  Activity,
  Database,
  Zap,
  BarChart3,
  Settings
} from 'lucide-react';
import { Button } from '../../ui/button';
import GlassCard from '../../GlassCard';
import { Badge } from '../../ui/badge';
import { mockAlerts, systemMetrics, systemStats, userStats } from '../../../data/adminConstants';

interface AdminOverviewTabProps {
  onSystemAction: (action: string) => void;
}

export default function AdminOverviewTab({ onSystemAction }: AdminOverviewTabProps) {
  return (
    <div className="space-y-8">
      {/* System Health Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {systemMetrics.map((metric, index) => (
          <motion.div
            key={metric.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -5 }}
          >
            <GlassCard accent="red" className="p-6 text-center group cursor-pointer">
              <motion.div
                whileHover={{ scale: 1.1, rotate: 10 }}
                className={`w-12 h-12 mx-auto mb-4 rounded-2xl flex items-center justify-center ${
                  metric.status === 'good' ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
                  metric.status === 'warning' ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                  'bg-gradient-to-r from-red-500 to-pink-500'
                }`}
              >
                <metric.icon className="w-6 h-6 text-white" />
              </motion.div>
              <div className="text-3xl font-bold text-white mb-2">{metric.value}</div>
              <div className="text-white/70">{metric.name}</div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Alerts & Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassCard className="p-6">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <AlertTriangle className="w-6 h-6 mr-2 text-red-400" />
            System Alerts
          </h3>
          <div className="space-y-4">
            {mockAlerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-xl border ${
                  alert.type === 'critical' ? 'bg-red-500/10 border-red-500/30' :
                  alert.type === 'warning' ? 'bg-yellow-500/10 border-yellow-500/30' :
                  'bg-blue-500/10 border-blue-500/30'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className={`font-medium ${
                      alert.type === 'critical' ? 'text-red-400' :
                      alert.type === 'warning' ? 'text-yellow-400' :
                      'text-blue-400'
                    }`}>
                      {alert.title}
                    </h4>
                    <p className="text-white/70 text-sm mt-1">{alert.message}</p>
                  </div>
                  <span className="text-white/50 text-xs">{alert.timestamp}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Activity className="w-6 h-6 mr-2 text-green-400" />
            System Statistics
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between p-4 rounded-xl bg-white/5">
              <span className="text-white/80">System Uptime</span>
              <span className="text-green-400 font-bold">{systemStats.uptime}</span>
            </div>
            <div className="flex justify-between p-4 rounded-xl bg-white/5">
              <span className="text-white/80">Total Users</span>
              <span className="text-white font-bold">{userStats.totalUsers}</span>
            </div>
            <div className="flex justify-between p-4 rounded-xl bg-white/5">
              <span className="text-white/80">Active Sessions</span>
              <span className="text-white font-bold">{systemStats.activeConnections}</span>
            </div>
            <div className="flex justify-between p-4 rounded-xl bg-white/5">
              <span className="text-white/80">Total Books</span>
              <span className="text-white font-bold">{systemStats.totalBooks}</span>
            </div>
            <div className="flex justify-between p-4 rounded-xl bg-white/5">
              <span className="text-white/80">Storage Used</span>
              <span className="text-amber-400 font-bold">{systemStats.storageUsed}</span>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Quick Actions */}
      <GlassCard className="p-6">
        <h3 className="text-2xl font-bold text-white mb-6">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button 
            onClick={() => onSystemAction('Backup Database')}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-2xl p-6 h-auto flex-col"
          >
            <Database className="w-8 h-8 mb-2" />
            Backup Database
          </Button>
          <Button 
            onClick={() => onSystemAction('Clear Cache')}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-2xl p-6 h-auto flex-col"
          >
            <Zap className="w-8 h-8 mb-2" />
            Clear Cache
          </Button>
          <Button 
            onClick={() => onSystemAction('Generate Report')}
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 rounded-2xl p-6 h-auto flex-col"
          >
            <BarChart3 className="w-8 h-8 mb-2" />
            Generate Report
          </Button>
          <Button 
            onClick={() => onSystemAction('System Maintenance')}
            className="bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 rounded-2xl p-6 h-auto flex-col"
          >
            <Settings className="w-8 h-8 mb-2" />
            Maintenance
          </Button>
        </div>
      </GlassCard>
    </div>
  );
}