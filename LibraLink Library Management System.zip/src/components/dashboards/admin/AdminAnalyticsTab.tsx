import React from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Activity, 
  PieChart, 
  Shield, 
  Database,
  Clock,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import GlassCard from '../../GlassCard';
import { systemStats } from '../../../data/adminConstants';

export default function AdminAnalyticsTab() {
  const performanceData = [
    { metric: 'API Response Time', value: 98, color: 'bg-green-500', unit: 'ms' },
    { metric: 'Database Query Time', value: 85, color: 'bg-blue-500', unit: 'ms' },
    { metric: 'Page Load Speed', value: 92, color: 'bg-purple-500', unit: 'ms' },
    { metric: 'Server Uptime', value: 99.9, color: 'bg-emerald-500', unit: '%' },
    { metric: 'Memory Usage', value: 68, color: 'bg-yellow-500', unit: '%' },
    { metric: 'CPU Usage', value: 45, color: 'bg-orange-500', unit: '%' }
  ];

  const userActivityData = [
    { role: 'Students', count: 1245, percentage: 78, color: 'bg-indigo-500' },
    { role: 'Faculty', count: 189, percentage: 12, color: 'bg-amber-500' },
    { role: 'Librarians', count: 89, percentage: 6, color: 'bg-green-500' },
    { role: 'Admins', count: 67, percentage: 4, color: 'bg-red-500' }
  ];

  const securityMetrics = [
    { name: 'Failed Login Attempts', value: 12, status: 'warning' },
    { name: 'Suspicious Activities', value: 3, status: 'alert' },
    { name: 'Security Scans', value: 24, status: 'success' },
    { name: 'Blocked IPs', value: 8, status: 'info' }
  ];

  const monthlyTrends = [
    { month: 'Jan', users: 1200, transactions: 4500, growth: 12 },
    { month: 'Feb', users: 1350, transactions: 5200, growth: 15 },
    { month: 'Mar', users: 1480, transactions: 5800, growth: 18 },
    { month: 'Apr', users: 1590, transactions: 6100, growth: 20 },
    { month: 'May', users: 1650, transactions: 6450, growth: 22 },
    { month: 'Jun', users: 1720, transactions: 6800, growth: 25 }
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent mb-2">
          System Analytics Dashboard
        </h3>
        <p className="text-white/60">Comprehensive system performance and usage analytics</p>
      </motion.div>

      {/* Key Performance Indicators */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6"
      >
        <GlassCard className="p-6 text-center">
          <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div className="text-2xl font-bold text-white mb-2">99.9%</div>
          <div className="text-white/70">System Uptime</div>
        </GlassCard>
        
        <GlassCard className="p-6 text-center">
          <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div className="text-2xl font-bold text-white mb-2">+28%</div>
          <div className="text-white/70">Growth Rate</div>
        </GlassCard>
        
        <GlassCard className="p-6 text-center">
          <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div className="text-2xl font-bold text-white mb-2">1,720</div>
          <div className="text-white/70">Active Users</div>
        </GlassCard>
        
        <GlassCard className="p-6 text-center">
          <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div className="text-2xl font-bold text-white mb-2">High</div>
          <div className="text-white/70">Security Level</div>
        </GlassCard>
      </motion.div>

      {/* Performance Metrics */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <GlassCard className="p-8">
          <h4 className="text-2xl font-bold text-white mb-6 flex items-center">
            <BarChart3 className="w-6 h-6 mr-2 text-blue-400" />
            System Performance Metrics
          </h4>
          <div className="space-y-6">
            {performanceData.map((item, index) => (
              <motion.div
                key={item.metric}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="space-y-2"
              >
                <div className="flex justify-between items-center">
                  <span className="text-white font-medium">{item.metric}</span>
                  <span className="text-white/80">{item.value}{item.unit}</span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                  <motion.div
                    className={`h-full ${item.color} rounded-full`}
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(item.value, 100)}%` }}
                    transition={{ duration: 1, delay: index * 0.2 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-8">
          <h4 className="text-2xl font-bold text-white mb-6 flex items-center">
            <PieChart className="w-6 h-6 mr-2 text-green-400" />
            User Distribution by Role
          </h4>
          <div className="space-y-6">
            {userActivityData.map((item, index) => (
              <motion.div
                key={item.role}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded-full ${item.color}`} />
                  <span className="text-white font-medium">{item.role}</span>
                </div>
                <div className="text-right">
                  <div className="text-white font-bold">{item.count.toLocaleString()}</div>
                  <div className="text-white/60 text-sm">{item.percentage}%</div>
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>
      </motion.div>

      {/* Monthly Trends */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <GlassCard className="p-8">
          <h4 className="text-2xl font-bold text-white mb-6 flex items-center">
            <TrendingUp className="w-6 h-6 mr-2 text-purple-400" />
            Growth Trends (6 Months)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Users Growth */}
            <div>
              <h5 className="text-lg font-semibold text-white mb-4">Active Users</h5>
              <div className="space-y-3">
                {monthlyTrends.map((month, index) => (
                  <div key={month.month} className="flex items-center space-x-4">
                    <span className="text-white/80 w-8">{month.month}</span>
                    <div className="flex-1 bg-white/10 rounded-full h-2">
                      <motion.div
                        className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${(month.users / 2000) * 100}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                      />
                    </div>
                    <span className="text-white font-medium w-12">{month.users}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Transactions */}
            <div>
              <h5 className="text-lg font-semibold text-white mb-4">Transactions</h5>
              <div className="space-y-3">
                {monthlyTrends.map((month, index) => (
                  <div key={month.month} className="flex items-center space-x-4">
                    <span className="text-white/80 w-8">{month.month}</span>
                    <div className="flex-1 bg-white/10 rounded-full h-2">
                      <motion.div
                        className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${(month.transactions / 8000) * 100}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                      />
                    </div>
                    <span className="text-white font-medium w-12">{month.transactions}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Growth Rate */}
            <div>
              <h5 className="text-lg font-semibold text-white mb-4">Growth Rate (%)</h5>
              <div className="space-y-3">
                {monthlyTrends.map((month, index) => (
                  <div key={month.month} className="flex items-center space-x-4">
                    <span className="text-white/80 w-8">{month.month}</span>
                    <div className="flex-1 bg-white/10 rounded-full h-2">
                      <motion.div
                        className="h-full bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${(month.growth / 30) * 100}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                      />
                    </div>
                    <span className="text-white font-medium w-12">+{month.growth}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </GlassCard>
      </motion.div>

      {/* Security & System Health */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <GlassCard className="p-8">
          <h4 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Shield className="w-6 h-6 mr-2 text-red-400" />
            Security Metrics
          </h4>
          <div className="space-y-4">
            {securityMetrics.map((metric, index) => (
              <motion.div
                key={metric.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-xl border ${
                  metric.status === 'success' ? 'bg-green-500/10 border-green-500/20' :
                  metric.status === 'warning' ? 'bg-yellow-500/10 border-yellow-500/20' :
                  metric.status === 'alert' ? 'bg-red-500/10 border-red-500/20' :
                  'bg-blue-500/10 border-blue-500/20'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="text-white font-medium">{metric.name}</span>
                  <div className="flex items-center space-x-2">
                    <span className={`font-bold ${
                      metric.status === 'success' ? 'text-green-400' :
                      metric.status === 'warning' ? 'text-yellow-400' :
                      metric.status === 'alert' ? 'text-red-400' :
                      'text-blue-400'
                    }`}>
                      {metric.value}
                    </span>
                    {metric.status === 'success' ? <CheckCircle className="w-4 h-4 text-green-400" /> :
                     metric.status === 'warning' || metric.status === 'alert' ? <AlertTriangle className="w-4 h-4 text-yellow-400" /> :
                     <Clock className="w-4 h-4 text-blue-400" />}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-8">
          <h4 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Database className="w-6 h-6 mr-2 text-purple-400" />
            System Health Status
          </h4>
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between p-4 rounded-xl bg-white/5">
                <span className="text-white/80">Daily Active Users</span>
                <span className="text-white font-bold">1,720</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-white/5">
                <span className="text-white/80">Books Borrowed Today</span>
                <span className="text-white font-bold">187</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-white/5">
                <span className="text-white/80">System Transactions</span>
                <span className="text-white font-bold">{systemStats.totalTransactions}</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-white/5">
                <span className="text-white/80">Data Transfer</span>
                <span className="text-white font-bold">{systemStats.dataTransfer}</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-green-500/10">
                <span className="text-white/80">Average Response Time</span>
                <span className="text-green-400 font-bold">98ms</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-green-500/10">
                <span className="text-white/80">Error Rate</span>
                <span className="text-green-400 font-bold">0.01%</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-green-500/10">
                <span className="text-white/80">Backup Status</span>
                <span className="text-green-400 font-bold">{systemStats.backupStatus}</span>
              </div>
              <div className="flex justify-between p-4 rounded-xl bg-white/5">
                <span className="text-white/80">Last Backup</span>
                <span className="text-white font-bold">{systemStats.lastBackup}</span>
              </div>
            </div>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
}