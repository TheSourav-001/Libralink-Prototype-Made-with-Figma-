import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Bell, 
  BookOpen, 
  LogOut, 
  ArrowLeft,
  Package,
  CheckCircle,
  XCircle,
  BarChart3,
  Plus,
  Edit,
  Clock,
  Users,
  TrendingUp,
  AlertTriangle,
  Library,
  Settings,
  UserCheck,
  BookMarked,
  Calendar,
  PieChart,
  Activity,
  Save,
  X
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import GlassCard from '../GlassCard';
import { User } from '../../App';
import { allBooks, Book } from '../../data/books';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner@2.0.3';

interface LibrarianDashboardProps {
  user: User;
  onLogout: () => void;
  onBack: () => void;
}

interface BorrowRequest {
  id: string;
  bookId: string;
  userId: string;
  userName: string;
  userRole: string;
  requestDate: string;
  type: 'borrow' | 'return' | 'reserve';
  status: 'pending' | 'approved' | 'rejected';
}

const mockRequests: BorrowRequest[] = [
  {
    id: '1',
    bookId: '1',
    userId: 'student1',
    userName: 'John Smith',
    userRole: 'student',
    requestDate: '2024-01-10',
    type: 'borrow',
    status: 'pending'
  },
  {
    id: '2',
    bookId: '5',
    userId: 'faculty1',
    userName: 'Dr. Jane Wilson',
    userRole: 'faculty',
    requestDate: '2024-01-09',
    type: 'reserve',
    status: 'pending'
  },
  {
    id: '3',
    bookId: '8',
    userId: 'student2',
    userName: 'Alice Johnson',
    userRole: 'student',
    requestDate: '2024-01-08',
    type: 'return',
    status: 'pending'
  },
  {
    id: '4',
    bookId: '12',
    userId: 'student3',
    userName: 'Michael Brown',
    userRole: 'student',
    requestDate: '2024-01-07',
    type: 'borrow',
    status: 'pending'
  },
  {
    id: '5',
    bookId: '15',
    userId: 'faculty2',
    userName: 'Prof. Sarah Davis',
    userRole: 'faculty',
    requestDate: '2024-01-06',
    type: 'reserve',
    status: 'pending'
  }
];

export default function LibrarianDashboard({ user, onLogout, onBack }: LibrarianDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'inventory' | 'requests' | 'analytics' | 'users'>('overview');
  const [pendingRequests, setPendingRequests] = useState(mockRequests);
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [showAddBookModal, setShowAddBookModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    description: '',
    category: 'Fiction',
    rating: 4.0,
    coverUrl: ''
  });

  const handleRequestAction = (requestId: string, action: 'approve' | 'reject') => {
    setPendingRequests(prev => 
      prev.map(req => 
        req.id === requestId 
          ? { ...req, status: action === 'approve' ? 'approved' as const : 'rejected' as const }
          : req
      )
    );
    
    const request = pendingRequests.find(r => r.id === requestId);
    const book = getBookById(request?.bookId || '');
    
    if (action === 'approve') {
      toast.success(`${request?.type} request approved for "${book?.title}"`);
    } else {
      toast.error(`${request?.type} request rejected for "${book?.title}"`);
    }
  };

  const getBookById = (id: string) => allBooks.find(book => book.id === id);

  const handleAddNewBook = () => {
    setShowAddBookModal(true);
  };

  const handleSubmitNewBook = () => {
    if (newBook.title && newBook.author) {
      toast.success(`"${newBook.title}" by ${newBook.author} has been added to the library!`);
      setNewBook({
        title: '',
        author: '',
        description: '',
        category: 'Fiction',
        rating: 4.0,
        coverUrl: ''
      });
      setShowAddBookModal(false);
    } else {
      toast.error('Please fill in all required fields');
    }
  };

  const handleShowSettings = () => {
    setShowSettingsModal(true);
  };

  const handleEditBook = (book: Book) => {
    setSelectedBook(book);
    toast.info(`Edit dialog for "${book.title}" would open here`);
  };

  const stats = {
    totalBooks: allBooks.length,
    availableBooks: allBooks.filter(b => b.status === 'available').length,
    borrowedBooks: allBooks.filter(b => b.status === 'borrowed').length,
    pendingRequests: pendingRequests.filter(r => r.status === 'pending').length,
    overdueBooks: 8,
    activeUsers: 179,
    reservations: 15,
    todayTransactions: 42
  };

  const categoriesData = [
    { name: 'Fiction', percentage: 80, count: 45, color: 'bg-blue-500' },
    { name: 'Science', percentage: 65, count: 38, color: 'bg-green-500' },
    { name: 'Technology', percentage: 50, count: 29, color: 'bg-purple-500' },
    { name: 'Fantasy', percentage: 35, count: 22, color: 'bg-pink-500' },
    { name: 'Business', percentage: 20, count: 15, color: 'bg-yellow-500' }
  ];

  return (
    <div className="min-h-screen">
      {/* Enhanced Librarian Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-green-900 to-teal-900" />
        <motion.div
          className="absolute inset-0"
          animate={{
            background: [
              'radial-gradient(circle at 20% 20%, rgba(16, 185, 129, 0.3) 0%, transparent 50%)',
              'radial-gradient(circle at 80% 80%, rgba(34, 197, 94, 0.3) 0%, transparent 50%)',
              'radial-gradient(circle at 40% 60%, rgba(20, 184, 166, 0.3) 0%, transparent 50%)',
              'radial-gradient(circle at 20% 20%, rgba(16, 185, 129, 0.3) 0%, transparent 50%)'
            ]
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
      </div>

      {/* Enhanced Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative backdrop-blur-3xl bg-white/5 border-b border-white/10 shadow-2xl"
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Section */}
            <div className="flex items-center space-x-4">
              <motion.button
                onClick={onBack}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20 text-white shadow-lg"
                whileHover={{ scale: 1.05, rotate: -5 }}
                whileTap={{ scale: 0.95 }}
              >
                <ArrowLeft className="w-5 h-5" />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-green-500/20 to-emerald-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
              
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
                  Library Management
                </h1>
                <p className="text-white/70 flex items-center space-x-2">
                  <Library className="w-4 h-4" />
                  <span>Librarian Dashboard - {user.name}</span>
                </p>
              </div>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-4">
              {/* Enhanced Search */}
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40 group-focus-within:text-white/70 transition-colors" />
                <Input
                  placeholder="Search books, users, requests..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 w-80 h-12 bg-gradient-to-r from-white/10 to-white/5 border-white/20 text-white placeholder-white/40 focus:border-green-400/50 backdrop-blur-xl rounded-2xl shadow-lg"
                />
              </div>

              {/* Notifications */}
              <motion.button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20 text-white shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Bell className="w-6 h-6" />
                {stats.pendingRequests > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg"
                  >
                    {stats.pendingRequests}
                  </motion.span>
                )}
              </motion.button>

              {/* Settings */}
              <Button 
                onClick={handleShowSettings}
                className="h-12 px-6 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 hover:from-green-600 hover:via-emerald-600 hover:to-teal-600 text-white border-0 rounded-2xl shadow-xl backdrop-blur-xl font-medium"
              >
                <Settings className="w-5 h-5 mr-2" />
                Settings
              </Button>

              {/* Logout */}
              <Button
                onClick={onLogout}
                variant="outline"
                className="h-12 border-white/20 text-white hover:bg-white/10 rounded-2xl backdrop-blur-xl"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Notifications Dropdown */}
        <AnimatePresence>
          {showNotifications && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="absolute top-full right-6 mt-2 w-96 z-[1000]"
            >
              <GlassCard className="p-6">
                <h3 className="text-xl font-bold text-white mb-4">Librarian Notifications</h3>
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  <motion.div
                    className="p-4 rounded-xl bg-white/10 hover:bg-white/15 cursor-pointer transition-all"
                    whileHover={{ x: 5 }}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 rounded-full mt-2 bg-green-400" />
                      <div className="flex-1">
                        <h4 className="font-medium text-white">New Book Request</h4>
                        <p className="text-white/70 text-sm">Faculty member requested "Machine Learning Basics"</p>
                        <p className="text-white/50 text-xs mt-1">30 minutes ago</p>
                      </div>
                    </div>
                  </motion.div>
                  <motion.div
                    className="p-4 rounded-xl bg-white/10 hover:bg-white/15 cursor-pointer transition-all"
                    whileHover={{ x: 5 }}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 rounded-full mt-2 bg-red-400" />
                      <div className="flex-1">
                        <h4 className="font-medium text-white">Overdue Book Alert</h4>
                        <p className="text-white/70 text-sm">Student has overdue book: "Data Structures"</p>
                        <p className="text-white/50 text-xs mt-1">2 hours ago</p>
                      </div>
                    </div>
                  </motion.div>
                  <motion.div
                    className="p-4 rounded-xl bg-white/5 hover:bg-white/15 cursor-pointer transition-all"
                    whileHover={{ x: 5 }}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 rounded-full mt-2 bg-gray-400" />
                      <div className="flex-1">
                        <h4 className="font-medium text-white">System Backup Complete</h4>
                        <p className="text-white/70 text-sm">Weekly library database backup completed successfully</p>
                        <p className="text-white/50 text-xs mt-1">1 day ago</p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </GlassCard>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Enhanced Navigation Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex space-x-2 mb-8 overflow-x-auto"
        >
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'inventory', label: 'Inventory', icon: Package },
            { id: 'requests', label: 'Requests', icon: Clock },
            { id: 'users', label: 'Users', icon: Users },
            { id: 'analytics', label: 'Analytics', icon: TrendingUp }
          ].map((tab) => (
            <motion.button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-3 px-6 py-3 rounded-2xl transition-all duration-300 whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 text-white shadow-lg'
                  : 'bg-white/10 text-white/70 hover:bg-white/20 backdrop-blur-xl'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <tab.icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
              {tab.id === 'requests' && stats.pendingRequests > 0 && (
                <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">
                  {stats.pendingRequests}
                </Badge>
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Analytics Tab with Enhanced Charts */}
        {activeTab === 'analytics' && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="space-y-8"
          >
            <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
              Library Analytics Dashboard
            </h3>

            {/* Enhanced Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <GlassCard className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white mb-2">98.5%</div>
                <div className="text-white/70">System Uptime</div>
              </GlassCard>
              
              <GlassCard className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white mb-2">+24%</div>
                <div className="text-white/70">Usage Growth</div>
              </GlassCard>
              
              <GlassCard className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                  <UserCheck className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white mb-2">4.8/5</div>
                <div className="text-white/70">User Satisfaction</div>
              </GlassCard>
              
              <GlassCard className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-center">
                  <PieChart className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white mb-2">85%</div>
                <div className="text-white/70">Collection Usage</div>
              </GlassCard>
            </div>

            {/* Book Categories Distribution */}
            <GlassCard className="p-8">
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
                <PieChart className="w-6 h-6 mr-2 text-green-400" />
                Book Categories Distribution
              </h3>
              <div className="space-y-6">
                {categoriesData.map((category, index) => (
                  <motion.div
                    key={category.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-white font-medium">{category.name}</span>
                      <span className="text-white/80">{category.count} books ({category.percentage}%)</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                      <motion.div
                        className={`h-full ${category.color} rounded-full`}
                        initial={{ width: 0 }}
                        animate={{ width: `${category.percentage}%` }}
                        transition={{ duration: 1, delay: index * 0.2 }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </GlassCard>

            {/* Usage Trends */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <GlassCard className="p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <BarChart3 className="w-6 h-6 mr-2 text-blue-400" />
                  Monthly Borrowing Trends
                </h3>
                <div className="space-y-4">
                  {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'].map((month, index) => {
                    const value = Math.floor(Math.random() * 100) + 50;
                    return (
                      <div key={month} className="flex items-center space-x-4">
                        <span className="text-white/80 w-8">{month}</span>
                        <div className="flex-1 bg-white/10 rounded-full h-2">
                          <motion.div
                            className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${value}%` }}
                            transition={{ duration: 1, delay: index * 0.1 }}
                          />
                        </div>
                        <span className="text-white font-medium w-12">{value}</span>
                      </div>
                    );
                  })}
                </div>
              </GlassCard>

              <GlassCard className="p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <Users className="w-6 h-6 mr-2 text-green-400" />
                  User Activity by Role
                </h3>
                <div className="space-y-6">
                  {[
                    { role: 'Students', count: 145, percentage: 81 },
                    { role: 'Faculty', count: 28, percentage: 16 },
                    { role: 'Staff', count: 6, percentage: 3 }
                  ].map((item, index) => (
                    <motion.div
                      key={item.role}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 rounded-full ${
                          index === 0 ? 'bg-blue-500' : 
                          index === 1 ? 'bg-amber-500' : 'bg-green-500'
                        }`} />
                        <span className="text-white font-medium">{item.role}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-bold">{item.count}</div>
                        <div className="text-white/60 text-sm">{item.percentage}%</div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </GlassCard>
            </div>
          </motion.div>
        )}

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="space-y-8"
          >
            {/* Enhanced Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <motion.div whileHover={{ y: -5 }}>
                <GlassCard accent="green" className="p-6 text-center group cursor-pointer">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 10 }}
                    className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center"
                  >
                    <BookOpen className="w-6 h-6 text-white" />
                  </motion.div>
                  <div className="text-3xl font-bold text-white mb-2">{stats.totalBooks}</div>
                  <div className="text-white/70">Total Books</div>
                </GlassCard>
              </motion.div>
              
              <motion.div whileHover={{ y: -5 }}>
                <GlassCard accent="green" className="p-6 text-center group cursor-pointer">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 10 }}
                    className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 flex items-center justify-center"
                  >
                    <CheckCircle className="w-6 h-6 text-white" />
                  </motion.div>
                  <div className="text-3xl font-bold text-white mb-2">{stats.availableBooks}</div>
                  <div className="text-white/70">Available</div>
                </GlassCard>
              </motion.div>
              
              <motion.div whileHover={{ y: -5 }}>
                <GlassCard accent="green" className="p-6 text-center group cursor-pointer">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 10 }}
                    className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 flex items-center justify-center"
                  >
                    <Clock className="w-6 h-6 text-white" />
                  </motion.div>
                  <div className="text-3xl font-bold text-white mb-2">{stats.borrowedBooks}</div>
                  <div className="text-white/70">Borrowed</div>
                </GlassCard>
              </motion.div>
              
              <motion.div whileHover={{ y: -5 }}>
                <GlassCard accent="green" className="p-6 text-center group cursor-pointer">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 10 }}
                    className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center"
                  >
                    <AlertTriangle className="w-6 h-6 text-white" />
                  </motion.div>
                  <div className="text-3xl font-bold text-white mb-2">{stats.pendingRequests}</div>
                  <div className="text-white/70">Pending Requests</div>
                </GlassCard>
              </motion.div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <GlassCard className="p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <TrendingUp className="w-6 h-6 mr-2 text-green-400" />
                  Today's Activity
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-white/80">Books Borrowed</span>
                    <span className="text-white font-medium">{stats.todayTransactions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/80">Books Returned</span>
                    <span className="text-white font-medium">28</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/80">New Reservations</span>
                    <span className="text-white font-medium">{stats.reservations}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/80">Active Users</span>
                    <span className="text-white font-medium">{stats.activeUsers}</span>
                  </div>
                </div>
              </GlassCard>

              <GlassCard className="p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <AlertTriangle className="w-6 h-6 mr-2 text-red-400" />
                  Urgent Actions
                </h3>
                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20">
                    <div className="flex justify-between items-center">
                      <span className="text-red-400 font-medium">Overdue Books</span>
                      <span className="text-red-400 font-bold">{stats.overdueBooks}</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                    <div className="flex justify-between items-center">
                      <span className="text-yellow-400 font-medium">Pending Returns</span>
                      <span className="text-yellow-400 font-bold">5</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
                    <div className="flex justify-between items-center">
                      <span className="text-blue-400 font-medium">Low Stock</span>
                      <span className="text-blue-400 font-bold">3</span>
                    </div>
                  </div>
                </div>
              </GlassCard>

              <GlassCard className="p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <Calendar className="w-6 h-6 mr-2 text-blue-400" />
                  Quick Actions
                </h3>
                <div className="space-y-3">
                  <Button 
                    onClick={handleAddNewBook}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-xl"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Book
                  </Button>
                  <Button 
                    onClick={() => setActiveTab('requests')}
                    variant="outline" 
                    className="w-full border-white/20 text-white hover:bg-white/10 rounded-xl"
                  >
                    <Clock className="w-4 h-4 mr-2" />
                    Review Requests
                  </Button>
                  <Button 
                    onClick={() => setActiveTab('analytics')}
                    variant="outline" 
                    className="w-full border-white/20 text-white hover:bg-white/10 rounded-xl"
                  >
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                </div>
              </GlassCard>
            </div>

            {/* Recent Activity */}
            <GlassCard className="p-6">
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Clock className="w-6 h-6 mr-2 text-green-400" />
                Recent Activity
              </h3>
              <div className="space-y-4">
                {pendingRequests.slice(0, 5).map((request, index) => {
                  const book = getBookById(request.bookId);
                  return (
                    <motion.div 
                      key={request.id} 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center space-x-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                    >
                      <motion.div 
                        className="w-12 h-12 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-center"
                        whileHover={{ scale: 1.1, rotate: 10 }}
                      >
                        {request.type === 'borrow' ? <BookOpen className="w-6 h-6 text-white" /> :
                         request.type === 'return' ? <CheckCircle className="w-6 h-6 text-white" /> :
                         <Clock className="w-6 h-6 text-white" />}
                      </motion.div>
                      <div className="flex-1">
                        <p className="text-white font-medium">
                          {request.userName} wants to {request.type} "{book?.title}"
                        </p>
                        <p className="text-white/70 text-sm">
                          {new Date(request.requestDate).toLocaleDateString()} • {request.userRole}
                        </p>
                      </div>
                      <Badge className={`${
                        request.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                        request.status === 'approved' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                        'bg-red-500/20 text-red-400 border-red-500/30'
                      }`}>
                        {request.status}
                      </Badge>
                    </motion.div>
                  );
                })}
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Inventory Tab */}
        {activeTab === 'inventory' && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="space-y-6"
          >
            <div className="flex justify-between items-center">
              <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
                Inventory Management
              </h3>
              <Button 
                onClick={handleAddNewBook}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-2xl"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add New Book
              </Button>
            </div>

            <GlassCard className="p-6">
              <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto">
                {allBooks.slice(0, 20).map((book, index) => (
                  <motion.div 
                    key={book.id} 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center space-x-6 p-6 rounded-2xl bg-white/5 hover:bg-white/10 transition-all border border-white/10"
                  >
                    <ImageWithFallback
                      src={book.coverUrl}
                      alt={book.title}
                      className="w-20 h-28 object-cover rounded-xl shadow-lg"
                    />
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-white mb-1">{book.title}</h4>
                      <p className="text-white/70 mb-2">by {book.author}</p>
                      <div className="flex items-center space-x-3">
                        <Badge className={`${
                          book.status === 'available' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                          book.status === 'borrowed' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                          'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                        }`}>
                          {book.status}
                        </Badge>
                        <span className="text-white/60">{book.category}</span>
                        <span className="text-white/60">Rating: {book.rating}/5</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        onClick={() => handleEditBook(book)}
                        size="sm" 
                        variant="outline" 
                        className="border-white/20 text-white hover:bg-white/10 rounded-xl"
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Requests Tab */}
        {activeTab === 'requests' && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="space-y-6"
          >
            <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
              Pending Requests ({stats.pendingRequests})
            </h3>

            <div className="space-y-6">
              {pendingRequests.filter(r => r.status === 'pending').map((request, index) => {
                const book = getBookById(request.bookId);
                return (
                  <motion.div
                    key={request.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <GlassCard className="p-8">
                      <div className="flex items-center space-x-8">
                        <ImageWithFallback
                          src={book?.coverUrl || ''}
                          alt={book?.title || ''}
                          className="w-24 h-32 object-cover rounded-xl shadow-lg"
                        />
                        
                        <div className="flex-1">
                          <h4 className="text-2xl font-bold text-white mb-2">{book?.title}</h4>
                          <p className="text-white/70 mb-2">by {book?.author}</p>
                          <div className="space-y-2">
                            <p className="text-white font-medium">Requested by: {request.userName}</p>
                            <p className="text-white/60">
                              Role: {request.userRole} • Date: {new Date(request.requestDate).toLocaleDateString()}
                            </p>
                          </div>
                          
                          <div className="flex items-center space-x-3 mt-4">
                            <Badge className={`${
                              request.type === 'borrow' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                              request.type === 'return' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                              'bg-purple-500/20 text-purple-400 border-purple-500/30'
                            }`}>
                              {request.type.toUpperCase()}
                            </Badge>
                            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                              {request.status.toUpperCase()}
                            </Badge>
                            {request.userRole === 'faculty' && (
                              <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                PRIORITY
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col space-y-4">
                          <Button
                            onClick={() => handleRequestAction(request.id, 'approve')}
                            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-2xl px-8 py-3"
                          >
                            <CheckCircle className="w-5 h-5 mr-2" />
                            Approve
                          </Button>
                          <Button
                            onClick={() => handleRequestAction(request.id, 'reject')}
                            variant="outline"
                            className="border-red-500/30 text-red-400 hover:bg-red-500/10 rounded-2xl px-8 py-3"
                          >
                            <XCircle className="w-5 h-5 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </GlassCard>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="space-y-6"
          >
            <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
              User Management
            </h3>
            
            <GlassCard className="p-6">
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-white/40 mx-auto mb-4" />
                <h4 className="text-xl font-medium text-white mb-2">User Management Coming Soon</h4>
                <p className="text-white/70">Advanced user management features will be available here.</p>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </div>

      {/* Add New Book Modal */}
      <AnimatePresence>
        {showAddBookModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[1000] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="max-w-2xl w-full"
            >
              <GlassCard className="p-8">
                <div className="flex justify-between items-start mb-8">
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
                    Add New Book
                  </h2>
                  <motion.button
                    onClick={() => setShowAddBookModal(false)}
                    className="text-white/70 hover:text-white text-2xl p-2 rounded-full hover:bg-white/10 transition-all"
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <X className="w-6 h-6" />
                  </motion.button>
                </div>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-white/70 mb-2 block">Title *</label>
                      <Input
                        value={newBook.title}
                        onChange={(e) => setNewBook(prev => ({ ...prev, title: e.target.value }))}
                        placeholder="Enter book title"
                        className="bg-white/10 border-white/20 text-white placeholder-white/40"
                      />
                    </div>
                    <div>
                      <label className="text-white/70 mb-2 block">Author *</label>
                      <Input
                        value={newBook.author}
                        onChange={(e) => setNewBook(prev => ({ ...prev, author: e.target.value }))}
                        placeholder="Enter author name"
                        className="bg-white/10 border-white/20 text-white placeholder-white/40"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-white/70 mb-2 block">Description</label>
                    <Textarea
                      value={newBook.description}
                      onChange={(e) => setNewBook(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Enter book description"
                      className="bg-white/10 border-white/20 text-white placeholder-white/40 h-24"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-white/70 mb-2 block">Category</label>
                      <Select value={newBook.category} onValueChange={(value) => setNewBook(prev => ({ ...prev, category: value }))}>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Fiction">Fiction</SelectItem>
                          <SelectItem value="Science">Science</SelectItem>
                          <SelectItem value="Technology">Technology</SelectItem>
                          <SelectItem value="Fantasy">Fantasy</SelectItem>
                          <SelectItem value="Business">Business</SelectItem>
                          <SelectItem value="Self-Help">Self-Help</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-white/70 mb-2 block">Cover URL</label>
                      <Input
                        value={newBook.coverUrl}
                        onChange={(e) => setNewBook(prev => ({ ...prev, coverUrl: e.target.value }))}
                        placeholder="Enter cover image URL"
                        className="bg-white/10 border-white/20 text-white placeholder-white/40"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-4 pt-6">
                    <Button
                      onClick={() => setShowAddBookModal(false)}
                      variant="outline"
                      className="border-white/20 text-white hover:bg-white/10 rounded-xl px-8"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleSubmitNewBook}
                      className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-xl px-8"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Add Book
                    </Button>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettingsModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[1000] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="max-w-2xl w-full"
            >
              <GlassCard className="p-8">
                <div className="flex justify-between items-start mb-8">
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent">
                    Library Settings
                  </h2>
                  <motion.button
                    onClick={() => setShowSettingsModal(false)}
                    className="text-white/70 hover:text-white text-2xl p-2 rounded-full hover:bg-white/10 transition-all"
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <X className="w-6 h-6" />
                  </motion.button>
                </div>
                
                <div className="space-y-8">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-4">General Settings</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                        <div>
                          <div className="text-white font-medium">Email Notifications</div>
                          <div className="text-white/60 text-sm">Receive email alerts for overdue books</div>
                        </div>
                        <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                          Enable
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                        <div>
                          <div className="text-white font-medium">Auto-Approval</div>
                          <div className="text-white/60 text-sm">Automatically approve faculty requests</div>
                        </div>
                        <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                          Configure
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                        <div>
                          <div className="text-white font-medium">System Backup</div>
                          <div className="text-white/60 text-sm">Schedule automatic database backups</div>
                        </div>
                        <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                          Schedule
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-4 pt-6">
                    <Button
                      onClick={() => setShowSettingsModal(false)}
                      variant="outline"
                      className="border-white/20 text-white hover:bg-white/10 rounded-xl px-8"
                    >
                      Close
                    </Button>
                    <Button 
                      onClick={() => {
                        toast.success('Settings saved successfully!');
                        setShowSettingsModal(false);
                      }}
                      className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-xl px-8"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </Button>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}