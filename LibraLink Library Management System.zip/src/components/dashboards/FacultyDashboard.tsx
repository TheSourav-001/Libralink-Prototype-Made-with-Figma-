import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Bell, 
  BookOpen, 
  CreditCard, 
  LogOut, 
  ArrowLeft,
  Users,
  Star,
  Calendar,
  FileText,
  PlusCircle,
  GraduationCap,
  Clock,
  Award,
  BookMarked
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import GlassCard from '../GlassCard';
import BookCard from '../BookCard';
import PaymentSystem from '../PaymentSystem';
import { User } from '../../App';
import { allBooks, searchBooks, getBorrowedBooks, Book } from '../../data/books';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner@2.0.3';

interface FacultyDashboardProps {
  user: User;
  onLogout: () => void;
  onBack: () => void;
}

interface Course {
  id: string;
  name: string;
  code: string;
  students: number;
  books: Book[];
  semester: string;
}

const mockCourses: Course[] = [
  { 
    id: '1', 
    name: 'Introduction to Programming', 
    code: 'CS101', 
    students: 45, 
    books: allBooks.slice(0, 4),
    semester: 'Fall 2024'
  },
  { 
    id: '2', 
    name: 'Data Structures & Algorithms', 
    code: 'CS201', 
    students: 38, 
    books: allBooks.slice(4, 8),
    semester: 'Fall 2024'
  },
  { 
    id: '3', 
    name: 'Software Engineering', 
    code: 'CS301', 
    students: 29, 
    books: allBooks.slice(8, 12),
    semester: 'Fall 2024'
  }
];

export default function FacultyDashboard({ user, onLogout, onBack }: FacultyDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showBookDetails, setShowBookDetails] = useState<Book | null>(null);
  const [showPaymentSystem, setShowPaymentSystem] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);

  const borrowedBooks = getBorrowedBooks(user.id);
  const searchResults = searchQuery ? searchBooks(searchQuery) : allBooks;
  const categories = ['all', 'academic', 'research', 'reference', 'course-materials'];
  
  const filteredBooks = selectedCategory === 'all' 
    ? searchResults 
    : searchResults.filter(book => book.category.toLowerCase().includes(selectedCategory));

  const priorityBooks = allBooks.filter(book => 
    book.status === 'available' && (book.category === 'Science' || book.category === 'Technology')
  ).slice(0, 6);

  const recentlyAdded = allBooks.slice(0, 8);

  const handleBookClick = (book: Book) => {
    setShowBookDetails(book);
  };

  const handleAddToCourse = (book: Book, course: Course) => {
    toast.success(`"${book.title}" added to ${course.code} reading list`);
    setShowBookDetails(null);
  };

  const handleBorrowBook = (book: Book) => {
    if (book.status === 'available') {
      toast.success(`"${book.title}" borrowed with faculty priority!`);
      setShowBookDetails(null);
    } else {
      toast.info(`"${book.title}" reserved with priority access.`);
      setShowBookDetails(null);
    }
  };

  const handleCreateReadingList = (course: Course) => {
    toast.success(`Reading list created for ${course.code}`);
  };

  return (
    <div className="min-h-screen">
      {/* Enhanced Faculty Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-900 via-orange-900 to-red-900" />
        <motion.div
          className="absolute inset-0"
          animate={{
            background: [
              'radial-gradient(circle at 20% 20%, rgba(245, 158, 11, 0.4) 0%, transparent 50%)',
              'radial-gradient(circle at 80% 80%, rgba(249, 115, 22, 0.4) 0%, transparent 50%)',
              'radial-gradient(circle at 40% 60%, rgba(239, 68, 68, 0.4) 0%, transparent 50%)',
              'radial-gradient(circle at 20% 20%, rgba(245, 158, 11, 0.4) 0%, transparent 50%)'
            ]
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
      </div>

      {/* Enhanced Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative backdrop-blur-3xl bg-white/5 border-b border-white/10 shadow-2xl"
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Section */}
            <div className="flex items-center space-x-4">
              <motion.button
                onClick={onBack}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20 text-white shadow-lg"
                whileHover={{ scale: 1.05, rotate: -5 }}
                whileTap={{ scale: 0.95 }}
              >
                <ArrowLeft className="w-5 h-5" />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
              
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
                  Welcome, Professor {user.name}!
                </h1>
                <p className="text-white/70 flex items-center space-x-2">
                  <GraduationCap className="w-4 h-4" />
                  <span>Faculty Dashboard</span>
                </p>
              </div>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-4">
              {/* Enhanced Search */}
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40 group-focus-within:text-white/70 transition-colors" />
                <Input
                  placeholder="Search academic resources..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 w-80 h-12 bg-gradient-to-r from-white/10 to-white/5 border-white/20 text-white placeholder-white/40 focus:border-amber-400/50 backdrop-blur-xl rounded-2xl shadow-lg"
                />
              </div>

              {/* Notifications */}
              <motion.button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative group p-3 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 border border-white/20 text-white shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Bell className="w-6 h-6" />
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg"
                >
                  2
                </motion.span>
              </motion.button>

              {/* Pay Fees Button */}
              <Button 
                onClick={() => setShowPaymentSystem(true)}
                className="h-12 px-6 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-600 hover:via-orange-600 hover:to-red-600 text-white border-0 rounded-2xl shadow-xl backdrop-blur-xl font-medium"
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Pay Fees
              </Button>

              {/* Logout */}
              <Button
                onClick={onLogout}
                variant="outline"
                className="h-12 border-white/20 text-white hover:bg-white/10 rounded-2xl backdrop-blur-xl"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Notifications Dropdown */}
        <AnimatePresence>
          {showNotifications && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="absolute top-full right-6 mt-2 w-96 z-[1000]"
            >
            <GlassCard className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">Faculty Notifications</h3>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                <motion.div
                  className="p-4 rounded-xl bg-white/10 hover:bg-white/15 cursor-pointer transition-all"
                  whileHover={{ x: 5 }}
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 rounded-full mt-2 bg-amber-400" />
                    <div className="flex-1">
                      <h4 className="font-medium text-white">Course Book Request Approved</h4>
                      <p className="text-white/70 text-sm">Your request for "Advanced Algorithms" has been approved</p>
                      <p className="text-white/50 text-xs mt-1">1 hour ago</p>
                    </div>
                  </div>
                </motion.div>
                <motion.div
                  className="p-4 rounded-xl bg-white/5 hover:bg-white/15 cursor-pointer transition-all"
                  whileHover={{ x: 5 }}
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 rounded-full mt-2 bg-gray-400" />
                    <div className="flex-1">
                      <h4 className="font-medium text-white">Reading List Updated</h4>
                      <p className="text-white/70 text-sm">CS301 reading list has been updated with new materials</p>
                      <p className="text-white/50 text-xs mt-1">2 days ago</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </GlassCard>
          </motion.div>
        )}
        </AnimatePresence>
      </motion.header>

      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Enhanced Quick Stats */}
        <motion.section
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <motion.div whileHover={{ y: -5 }}>
              <GlassCard accent="amber" className="p-6 text-center group cursor-pointer">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 10 }}
                  className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 flex items-center justify-center"
                >
                  <BookOpen className="w-6 h-6 text-white" />
                </motion.div>
                <div className="text-3xl font-bold text-white mb-2">{borrowedBooks.length}</div>
                <div className="text-white/70">Borrowed Books</div>
              </GlassCard>
            </motion.div>
            
            <motion.div whileHover={{ y: -5 }}>
              <GlassCard accent="amber" className="p-6 text-center group cursor-pointer">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 10 }}
                  className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-center"
                >
                  <Users className="w-6 h-6 text-white" />
                </motion.div>
                <div className="text-3xl font-bold text-white mb-2">{mockCourses.length}</div>
                <div className="text-white/70">Active Courses</div>
              </GlassCard>
            </motion.div>
            
            <motion.div whileHover={{ y: -5 }}>
              <GlassCard accent="amber" className="p-6 text-center group cursor-pointer">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 10 }}
                  className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center"
                >
                  <FileText className="w-6 h-6 text-white" />
                </motion.div>
                <div className="text-3xl font-bold text-white mb-2">
                  {mockCourses.reduce((sum, course) => sum + course.books.length, 0)}
                </div>
                <div className="text-white/70">Course Materials</div>
              </GlassCard>
            </motion.div>
            
            <motion.div whileHover={{ y: -5 }}>
              <GlassCard accent="amber" className="p-6 text-center group cursor-pointer">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 10 }}
                  className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-500 flex items-center justify-center"
                >
                  <Award className="w-6 h-6 text-white" />
                </motion.div>
                <div className="text-3xl font-bold text-white mb-2">Priority</div>
                <div className="text-white/70">Access Level</div>
              </GlassCard>
            </motion.div>
          </div>
        </motion.section>

        {/* Enhanced Course Management */}
        <motion.section
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
              Course Management
            </h2>
            <Button className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 rounded-2xl">
              <PlusCircle className="w-5 h-5 mr-2" />
              Create Course
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {mockCourses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassCard hover className="p-6 h-full">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-1">{course.code}</h3>
                      <p className="text-white/70 text-sm">{course.name}</p>
                    </div>
                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                      {course.semester}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <span className="text-white/70">Students:</span>
                      <span className="text-white font-medium">{course.students}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/70">Books:</span>
                      <span className="text-white font-medium">{course.books.length}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2 mb-4">
                    <Button 
                      onClick={() => handleCreateReadingList(course)}
                      size="sm" 
                      className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl"
                    >
                      <BookMarked className="w-4 h-4 mr-1" />
                      Reading List
                    </Button>
                    <Button 
                      onClick={() => setSelectedCourse(course)}
                      size="sm" 
                      variant="outline" 
                      className="border-white/20 text-white hover:bg-white/10 rounded-xl"
                    >
                      <Calendar className="w-4 h-4 mr-1" />
                      Manage
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    {course.books.slice(0, 4).map((book) => (
                      <motion.div
                        key={book.id}
                        onClick={() => handleBookClick(book)}
                        className="cursor-pointer"
                        whileHover={{ scale: 1.05 }}
                      >
                        <ImageWithFallback
                          src={book.coverUrl}
                          alt={book.title}
                          className="w-full h-16 object-cover rounded-lg shadow-lg"
                        />
                      </motion.div>
                    ))}
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Priority Access Books */}
        <motion.section
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center space-x-3 mb-6">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            >
              <Star className="w-8 h-8 text-amber-400" />
            </motion.div>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
              Faculty Priority Access
            </h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {priorityBooks.map((book, index) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <BookCard
                  book={book}
                  onClick={handleBookClick}
                  size="small"
                />
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Recently Added Books */}
        <motion.section
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent mb-6">
            Recently Added to Collection
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {recentlyAdded.map((book, index) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <BookCard
                  book={book}
                  onClick={handleBookClick}
                  size="small"
                />
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Academic Collection */}
        <motion.section
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
              Academic Collection
            </h2>
            <div className="flex space-x-2 overflow-x-auto">
              {categories.map((category) => (
                <motion.button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-3 rounded-2xl font-medium transition-all duration-300 whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white shadow-lg'
                      : 'bg-white/10 text-white/70 hover:bg-white/20 backdrop-blur-xl'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
                </motion.button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {filteredBooks.slice(0, 100).map((book, index) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.02 }}
              >
                <BookCard
                  book={book}
                  onClick={handleBookClick}
                  size="small"
                />
              </motion.div>
            ))}
          </div>
        </motion.section>
      </div>

      {/* Enhanced Book Details Modal */}
      {showBookDetails && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          >
            <GlassCard className="p-8">
              <div className="flex justify-between items-start mb-8">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-white to-amber-200 bg-clip-text text-transparent">
                  {showBookDetails.title}
                </h2>
                <motion.button
                  onClick={() => setShowBookDetails(null)}
                  className="text-white/70 hover:text-white text-3xl p-2 rounded-full hover:bg-white/10 transition-all"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.95 }}
                >
                  ×
                </motion.button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <ImageWithFallback
                    src={showBookDetails.coverUrl}
                    alt={showBookDetails.title}
                    className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                  />
                </div>
                
                <div className="space-y-6">
                  <div>
                    <p className="text-white/70 mb-1">Author</p>
                    <p className="text-xl font-bold text-white">{showBookDetails.author}</p>
                  </div>
                  
                  <div>
                    <p className="text-white/70 mb-1">Description</p>
                    <p className="text-white/90 leading-relaxed">{showBookDetails.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-white/70 mb-1">Rating</p>
                      <div className="flex items-center space-x-2">
                        <Star className="w-5 h-5 text-yellow-400 fill-current" />
                        <span className="text-white font-medium">{showBookDetails.rating}/5</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-white/70 mb-1">Category</p>
                      <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                        {showBookDetails.category}
                      </Badge>
                    </div>
                  </div>

                  <div>
                    <p className="text-white/70 mb-2">Add to Course:</p>
                    <div className="flex flex-wrap gap-2">
                      {mockCourses.map((course) => (
                        <Button
                          key={course.id}
                          onClick={() => handleAddToCourse(showBookDetails, course)}
                          size="sm"
                          variant="outline"
                          className="border-white/20 text-white hover:bg-white/10 rounded-xl"
                        >
                          {course.code}
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex space-x-4 pt-4">
                    <Button 
                      onClick={() => handleBorrowBook(showBookDetails)}
                      className="flex-1 h-12 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-600 hover:via-orange-600 hover:to-red-600 rounded-2xl font-medium"
                    >
                      Priority {showBookDetails.status === 'available' ? 'Borrow' : 'Reserve'}
                    </Button>
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      )}

      {/* Payment System Modal */}
      {showPaymentSystem && (
        <PaymentSystem
          onClose={() => setShowPaymentSystem(false)}
          userRole="faculty"
        />
      )}
    </div>
  );
}