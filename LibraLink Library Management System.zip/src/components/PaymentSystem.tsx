import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CreditCard, 
  ArrowLeft, 
  CheckCircle, 
  AlertCircle,
  Smartphone,
  Building,
  Download,
  Receipt,
  X
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import GlassCard from './GlassCard';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';

interface PaymentSystemProps {
  onClose: () => void;
  userType: 'student' | 'faculty';
}

interface Fee {
  id: string;
  type: string;
  description: string;
  amount: number;
  dueDate: string;
  status: 'pending' | 'overdue' | 'paid';
}

const mockFees: Fee[] = [
  {
    id: '1',
    type: 'Library Fine',
    description: 'Overdue book: "Introduction to Algorithms"',
    amount: 15.50,
    dueDate: '2024-01-10',
    status: 'overdue'
  },
  {
    id: '2',
    type: 'Course Materials',
    description: 'Digital textbook access',
    amount: 89.99,
    dueDate: '2024-01-20',
    status: 'pending'
  },
  {
    id: '3',
    type: 'Library Card Renewal',
    description: 'Annual library card fee',
    amount: 25.00,
    dueDate: '2024-02-01',
    status: 'pending'
  }
];

const paymentMethods = [
  { id: 'card', name: 'Credit/Debit Card', icon: CreditCard },
  { id: 'bank', name: 'Bank Transfer', icon: Building },
  { id: 'mobile', name: 'Mobile Payment', icon: Smartphone }
];

export default function PaymentSystem({ onClose, userType }: PaymentSystemProps) {
  const [step, setStep] = useState<'overview' | 'method' | 'details' | 'confirmation' | 'success'>('overview');
  const [selectedFees, setSelectedFees] = useState<string[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    holderName: '',
    email: '',
    phone: ''
  });

  const totalAmount = mockFees
    .filter(fee => selectedFees.includes(fee.id))
    .reduce((sum, fee) => sum + fee.amount, 0);

  const handleFeeSelection = (feeId: string) => {
    setSelectedFees(prev => 
      prev.includes(feeId) 
        ? prev.filter(id => id !== feeId)
        : [...prev, feeId]
    );
  };

  const handlePayment = async () => {
    // Simulate payment processing
    setStep('success');
    toast.success('Payment processed successfully!');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Outstanding Fees</h2>
        <p className="text-white/70">Select fees to pay</p>
      </div>

      <div className="space-y-4">
        {mockFees.map((fee) => (
          <motion.div
            key={fee.id}
            onClick={() => handleFeeSelection(fee.id)}
            className={`p-4 cursor-pointer backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl transition-all duration-300 hover:bg-white/[0.12] ${
              selectedFees.includes(fee.id) ? 'ring-2 ring-green-400/50 bg-green-500/10' : ''
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            style={{
              backdropFilter: 'blur(20px) saturate(180%)',
              WebkitBackdropFilter: 'blur(20px) saturate(180%)',
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`w-5 h-5 rounded-full border-2 transition-all flex items-center justify-center ${
                  selectedFees.includes(fee.id) 
                    ? 'bg-green-400 border-green-400' 
                    : 'border-white/40'
                }`}>
                  {selectedFees.includes(fee.id) && (
                    <CheckCircle className="w-3 h-3 text-white" />
                  )}
                </div>
                <div>
                  <h3 className="font-medium text-white">{fee.type}</h3>
                  <p className="text-white/70 text-sm">{fee.description}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge className={`text-xs ${
                      fee.status === 'overdue' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                      fee.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                      'bg-green-500/20 text-green-400 border-green-500/30'
                    }`}>
                      {fee.status}
                    </Badge>
                    <span className="text-white/60 text-sm">Due: {new Date(fee.dueDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-white">${fee.amount.toFixed(2)}</div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {selectedFees.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 backdrop-blur-xl bg-green-500/10 border border-green-500/30 rounded-2xl"
          style={{
            backdropFilter: 'blur(20px) saturate(180%)',
            WebkitBackdropFilter: 'blur(20px) saturate(180%)',
          }}
        >
          <div className="flex justify-between items-center">
            <span className="text-white font-medium">Total Amount:</span>
            <span className="text-2xl font-bold text-white">${totalAmount.toFixed(2)}</span>
          </div>
        </motion.div>
      )}

      <Button
        onClick={() => setStep('method')}
        disabled={selectedFees.length === 0}
        className="w-full h-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:opacity-50 rounded-2xl transition-all duration-300"
      >
        Continue to Payment
      </Button>
    </div>
  );

  const renderMethodSelection = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Payment Method</h2>
        <p className="text-white/70">Choose your preferred payment method</p>
      </div>

      <div className="space-y-4">
        {paymentMethods.map((method) => (
          <motion.div
            key={method.id}
            onClick={() => setSelectedMethod(method.id)}
            className={`p-6 cursor-pointer backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl transition-all duration-300 hover:bg-white/[0.12] ${
              selectedMethod === method.id ? 'ring-2 ring-blue-400/50 bg-blue-500/10' : ''
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            style={{
              backdropFilter: 'blur(20px) saturate(180%)',
              WebkitBackdropFilter: 'blur(20px) saturate(180%)',
            }}
          >
            <div className="flex items-center space-x-4">
              <method.icon className={`w-8 h-8 ${
                selectedMethod === method.id ? 'text-blue-400' : 'text-white/60'
              } transition-colors duration-300`} />
              <span className="text-lg font-medium text-white">{method.name}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <Button
        onClick={() => setStep('details')}
        disabled={!selectedMethod}
        className="w-full h-12 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-2xl transition-all duration-300"
      >
        Continue
      </Button>
    </div>
  );

  const renderPaymentDetails = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Payment Details</h2>
        <p className="text-white/70">Enter your payment information</p>
      </div>

      {selectedMethod === 'card' && (
        <div className="space-y-4">
          <div>
            <Label className="text-white mb-2 block">Card Number</Label>
            <Input
              value={paymentData.cardNumber}
              onChange={(e) => setPaymentData(prev => ({ ...prev, cardNumber: e.target.value }))}
              placeholder="1234 5678 9012 3456"
              className="bg-white/10 border-white/20 text-white placeholder-white/40 rounded-xl backdrop-blur-xl h-12 transition-all duration-300 focus:bg-white/15"
              style={{
                backdropFilter: 'blur(20px) saturate(180%)',
                WebkitBackdropFilter: 'blur(20px) saturate(180%)',
              }}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white mb-2 block">Expiry Date</Label>
              <Input
                value={paymentData.expiryDate}
                onChange={(e) => setPaymentData(prev => ({ ...prev, expiryDate: e.target.value }))}
                placeholder="MM/YY"
                className="bg-white/10 border-white/20 text-white placeholder-white/40 rounded-xl backdrop-blur-xl h-12 transition-all duration-300 focus:bg-white/15"
                style={{
                  backdropFilter: 'blur(20px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                }}
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">CVV</Label>
              <Input
                value={paymentData.cvv}
                onChange={(e) => setPaymentData(prev => ({ ...prev, cvv: e.target.value }))}
                placeholder="123"
                className="bg-white/10 border-white/20 text-white placeholder-white/40 rounded-xl backdrop-blur-xl h-12 transition-all duration-300 focus:bg-white/15"
                style={{
                  backdropFilter: 'blur(20px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(180%)',
                }}
              />
            </div>
          </div>
          <div>
            <Label className="text-white mb-2 block">Cardholder Name</Label>
            <Input
              value={paymentData.holderName}
              onChange={(e) => setPaymentData(prev => ({ ...prev, holderName: e.target.value }))}
              placeholder="John Doe"
              className="bg-white/10 border-white/20 text-white placeholder-white/40 rounded-xl backdrop-blur-xl h-12 transition-all duration-300 focus:bg-white/15"
              style={{
                backdropFilter: 'blur(20px) saturate(180%)',
                WebkitBackdropFilter: 'blur(20px) saturate(180%)',
              }}
            />
          </div>
        </div>
      )}

      <Button
        onClick={() => setStep('confirmation')}
        className="w-full h-12 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 rounded-2xl transition-all duration-300"
      >
        Review Payment
      </Button>
    </div>
  );

  const renderConfirmation = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Confirm Payment</h2>
        <p className="text-white/70">Review your payment details</p>
      </div>

      <div 
        className="p-6 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
        style={{
          backdropFilter: 'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        }}
      >
        <h3 className="text-lg font-bold text-white mb-4">Payment Summary</h3>
        <div className="space-y-3">
          {mockFees.filter(fee => selectedFees.includes(fee.id)).map((fee) => (
            <div key={fee.id} className="flex justify-between">
              <span className="text-white/80">{fee.type}</span>
              <span className="text-white font-medium">${fee.amount.toFixed(2)}</span>
            </div>
          ))}
          <div className="border-t border-white/20 pt-3">
            <div className="flex justify-between text-lg font-bold">
              <span className="text-white">Total:</span>
              <span className="text-white">${totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <Button
        onClick={handlePayment}
        className="w-full h-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-2xl transition-all duration-300"
      >
        <CreditCard className="w-5 h-5 mr-2" />
        Pay Now
      </Button>
    </div>
  );

  const renderSuccess = () => (
    <div className="space-y-6 text-center">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
        className="w-24 h-24 mx-auto rounded-full bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-center shadow-2xl"
      >
        <CheckCircle className="w-12 h-12 text-white" />
      </motion.div>
      
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Payment Successful!</h2>
        <p className="text-white/70">Your payment has been processed successfully</p>
      </div>

      <div 
        className="p-6 backdrop-blur-xl bg-white/[0.08] border border-white/[0.15] rounded-2xl"
        style={{
          backdropFilter: 'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        }}
      >
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-white/70">Transaction ID:</span>
            <span className="text-white font-mono">TXN-{Date.now()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/70">Amount Paid:</span>
            <span className="text-white font-medium">${totalAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/70">Payment Date:</span>
            <span className="text-white">{new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      <div className="flex space-x-4">
        <Button
          onClick={onClose}
          className="flex-1 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 rounded-2xl transition-all duration-300"
        >
          Done
        </Button>
        <Button
          variant="outline"
          className="flex-1 h-12 border-white/20 text-white hover:bg-white/10 rounded-2xl transition-all duration-300"
        >
          <Download className="w-4 h-4 mr-2" />
          Download Receipt
        </Button>
      </div>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
      className="max-w-2xl w-full max-h-[90vh] overflow-y-auto"
    >
      <div 
        className="p-8 backdrop-blur-3xl bg-white/[0.08] border border-white/[0.15] rounded-2xl shadow-2xl"
        style={{
          backdropFilter: 'blur(40px) saturate(180%)',
          WebkitBackdropFilter: 'blur(40px) saturate(180%)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <motion.button
            onClick={step === 'overview' ? onClose : () => setStep('overview')}
            className="p-2 rounded-full backdrop-blur-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-300"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            style={{
              backdropFilter: 'blur(20px) saturate(180%)',
              WebkitBackdropFilter: 'blur(20px) saturate(180%)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
          </motion.button>
          <h1 className="text-2xl font-bold text-white">Payment Center</h1>
          <motion.button
            onClick={onClose}
            className="text-white/70 hover:text-white text-2xl p-2 rounded-full hover:bg-white/10 transition-all duration-300"
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.95 }}
          >
            <X className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            {step === 'overview' && renderOverview()}
            {step === 'method' && renderMethodSelection()}
            {step === 'details' && renderPaymentDetails()}
            {step === 'confirmation' && renderConfirmation()}
            {step === 'success' && renderSuccess()}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}