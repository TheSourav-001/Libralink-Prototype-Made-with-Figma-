import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, GraduationCap, Users, BookOpen, Shield } from 'lucide-react';
import GlassCard from './GlassCard';
import { UserRole } from '../App';

interface RoleSelectionProps {
  onRoleSelect: (role: UserRole) => void;
  onBack: () => void;
}

const roles = [
  {
    id: 'student' as UserRole,
    title: 'Student',
    description: 'Access books, track borrowings, and manage your academic library needs',
    icon: GraduationCap,
    accent: 'indigo' as const,
    gradient: 'from-indigo-500 to-blue-600'
  },
  {
    id: 'faculty' as UserRole,
    title: 'Faculty',
    description: 'Manage course materials, priority access, and academic collections',
    icon: Users,
    accent: 'amber' as const,
    gradient: 'from-amber-500 to-orange-600'
  },
  {
    id: 'librarian' as UserRole,
    title: 'Librarian',
    description: 'Oversee inventory, approve requests, and manage library operations',
    icon: BookOpen,
    accent: 'green' as const,
    gradient: 'from-green-500 to-emerald-600'
  },
  {
    id: 'admin' as UserRole,
    title: 'Administrator',
    description: 'Full system control, analytics, and comprehensive management tools',
    icon: Shield,
    accent: 'red' as const,
    gradient: 'from-red-500 to-pink-600'
  }
];

export default function RoleSelection({ onRoleSelect, onBack }: RoleSelectionProps) {
  return (
    <div className="min-h-screen p-6 relative">
      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="fixed top-6 left-6 z-50 p-3 rounded-full backdrop-blur-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-300 shadow-xl hover:scale-110"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <ArrowLeft className="w-6 h-6" />
      </motion.button>

      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-12 pt-20"
        >
          <h1 className="text-5xl font-bold text-white mb-4 bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
            Choose Your Role
          </h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Select your role to access personalized features and dashboard
          </p>
        </motion.div>

        {/* Role Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {roles.map((role, index) => (
            <motion.div
              key={role.id}
              initial={{ y: 50, opacity: 0, scale: 0.9 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              transition={{ 
                delay: index * 0.1,
                duration: 0.8,
                ease: "easeOut"
              }}
            >
              <GlassCard
                hover
                accent={role.accent}
                onClick={() => onRoleSelect(role.id)}
                className="p-8 h-80 flex flex-col items-center text-center group"
              >
                {/* Icon Container */}
                <motion.div
                  className={`relative w-20 h-20 rounded-full bg-gradient-to-r ${role.gradient} flex items-center justify-center mb-6 shadow-2xl`}
                  whileHover={{ 
                    scale: 1.1,
                    rotate: [0, -10, 10, 0],
                  }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  {/* Glow effect */}
                  <div className={`absolute inset-0 rounded-full bg-gradient-to-r ${role.gradient} opacity-50 blur-xl group-hover:opacity-75 transition-opacity duration-300`} />
                  
                  <role.icon className="w-10 h-10 text-white relative z-10" />
                  
                  {/* Floating particles */}
                  <motion.div
                    className="absolute inset-0"
                    initial={false}
                    whileHover={{
                      rotate: 360
                    }}
                    transition={{ duration: 2, ease: "linear" }}
                  >
                    {Array.from({ length: 4 }).map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-1.5 h-1.5 bg-white/60 rounded-full"
                        style={{
                          left: '50%',
                          top: '50%',
                          transformOrigin: `${25 + i * 5}px center`,
                        }}
                        animate={{
                          rotate: [0, 360],
                          scale: [0, 1, 0],
                          opacity: [0, 1, 0]
                        }}
                        transition={{
                          duration: 3,
                          repeat: Infinity,
                          delay: i * 0.5,
                          ease: "easeInOut"
                        }}
                      />
                    ))}
                  </motion.div>
                </motion.div>

                {/* Title */}
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-200 group-hover:bg-clip-text transition-all duration-300">
                  {role.title}
                </h3>

                {/* Description */}
                <p className="text-white/80 leading-relaxed group-hover:text-white/90 transition-colors duration-300">
                  {role.description}
                </p>

                {/* Hover indicator */}
                <motion.div
                  className="mt-auto pt-6"
                  initial={{ opacity: 0, y: 10 }}
                  whileHover={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-12 h-1 bg-gradient-to-r from-white/50 to-transparent rounded-full" />
                </motion.div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}