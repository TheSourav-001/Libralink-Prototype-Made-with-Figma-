import React from 'react';
import { motion } from 'motion/react';
import { Star, Clock, User, CheckCircle, XCircle, Calendar, Heart } from 'lucide-react';
import { Book } from '../data/books';
import GlassCard from './GlassCard';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface BookCardProps {
  book: Book;
  onClick: (book: Book) => void;
  size?: 'small' | 'medium' | 'large';
}

const statusColors = {
  available: 'text-green-400 bg-green-500/20 border-green-500/30',
  borrowed: 'text-red-400 bg-red-500/20 border-red-500/30',
  reserved: 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30'
};

const statusIcons = {
  available: CheckCircle,
  borrowed: XCircle,
  reserved: Clock
};

export default function BookCard({ book, onClick, size = 'medium' }: BookCardProps) {
  const StatusIcon = statusIcons[book.status];
  
  const cardSizes = {
    small: 'w-48 h-80',
    medium: 'w-56 h-96',
    large: 'w-64 h-[26rem]'
  };

  const imageSizes = {
    small: 'h-36',
    medium: 'h-48',
    large: 'h-56'
  };

  const textSizes = {
    small: { title: 'text-sm', author: 'text-xs', category: 'text-xs' },
    medium: { title: 'text-base', author: 'text-sm', category: 'text-xs' },
    large: { title: 'text-lg', author: 'text-base', category: 'text-sm' }
  };

  return (
    <motion.div
      className={`${cardSizes[size]} flex-shrink-0`}
      whileHover={{ scale: 1.03, y: -8 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
    >
      <GlassCard
        hover
        onClick={() => onClick(book)}
        className="h-full p-5 flex flex-col cursor-pointer group relative overflow-hidden"
      >
        {/* Gradient Background Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Book Cover */}
        <div className={`relative ${imageSizes[size]} rounded-2xl overflow-hidden mb-4 shadow-2xl group-hover:shadow-3xl transition-shadow duration-500`}>
          <ImageWithFallback
            src={book.coverUrl}
            alt={book.title}
            className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:brightness-110"
          />
          
          {/* Enhanced Status Badge */}
          <motion.div 
            className={`absolute top-3 right-3 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 backdrop-blur-xl border ${statusColors[book.status]} shadow-lg`}
            whileHover={{ scale: 1.05 }}
          >
            <StatusIcon className="w-3.5 h-3.5" />
            <span className="capitalize">{book.status}</span>
          </motion.div>

          {/* Enhanced Rating Badge */}
          <motion.div 
            className="absolute bottom-3 left-3 px-3 py-1.5 rounded-xl bg-black/60 backdrop-blur-xl border border-white/20 text-white text-xs font-bold flex items-center space-x-1.5 shadow-lg"
            whileHover={{ scale: 1.05 }}
          >
            <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
            <span>{book.rating.toFixed(1)}/5</span>
          </motion.div>

          {/* Quick Action Button */}
          <motion.div
            className="absolute top-3 left-3 p-2 rounded-xl bg-white/10 backdrop-blur-xl border border-white/20 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Heart className="w-4 h-4" />
          </motion.div>

          {/* Enhanced Hover Overlay */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end justify-center p-4"
            initial={false}
          >
            <motion.div
              className="text-center"
              initial={{ y: 20, opacity: 0 }}
              whileHover={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <div className="text-white font-bold text-sm mb-1">
                Click to view
              </div>
              <div className="text-white/80 text-xs">
                Full details & actions
              </div>
            </motion.div>
          </motion.div>

          {/* Shimmer Effect */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 opacity-0 group-hover:opacity-100"
            animate={{
              x: ['-100%', '100%']
            }}
            transition={{
              duration: 1.5,
              ease: "easeInOut",
              repeat: Infinity,
              repeatDelay: 3
            }}
          />
        </div>

        {/* Book Info */}
        <div className="flex-1 flex flex-col space-y-3 relative z-10">
          <motion.h3 
            className={`font-bold text-white ${textSizes[size].title} leading-tight line-clamp-2 group-hover:text-blue-200 transition-colors duration-300`}
            whileHover={{ scale: 1.02 }}
          >
            {book.title}
          </motion.h3>
          
          <motion.p 
            className={`text-white/70 ${textSizes[size].author} group-hover:text-white/90 transition-colors duration-300`}
            whileHover={{ scale: 1.02 }}
          >
            by {book.author}
          </motion.p>

          {/* Enhanced Metadata */}
          <div className="space-y-2 flex-1">
            <div className="flex items-center space-x-2 text-white/60 text-xs">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-medium">{book.year}</span>
            </div>
            
            <motion.div 
              className={`${textSizes[size].category} bg-gradient-to-r from-white/10 to-white/20 px-3 py-2 rounded-xl text-center font-medium text-white/90 border border-white/10 group-hover:from-white/20 group-hover:to-white/30 transition-all duration-300`}
              whileHover={{ scale: 1.05 }}
            >
              {book.category}
            </motion.div>
          </div>

          {/* Enhanced Additional Status Info */}
          {book.status === 'borrowed' && book.dueDate && (
            <motion.div 
              className="flex items-center space-x-2 text-red-300 text-xs bg-red-500/10 px-3 py-2 rounded-xl border border-red-500/20 mt-auto"
              whileHover={{ scale: 1.02 }}
            >
              <Clock className="w-3.5 h-3.5" />
              <span className="font-medium">Due: {new Date(book.dueDate).toLocaleDateString()}</span>
            </motion.div>
          )}

          {book.status === 'reserved' && book.reservedBy && (
            <motion.div 
              className="flex items-center space-x-2 text-yellow-300 text-xs bg-yellow-500/10 px-3 py-2 rounded-xl border border-yellow-500/20 mt-auto"
              whileHover={{ scale: 1.02 }}
            >
              <User className="w-3.5 h-3.5" />
              <span className="font-medium">Reserved</span>
            </motion.div>
          )}

          {book.status === 'available' && (
            <motion.div 
              className="flex items-center space-x-2 text-green-300 text-xs bg-green-500/10 px-3 py-2 rounded-xl border border-green-500/20 mt-auto"
              whileHover={{ scale: 1.02 }}
            >
              <CheckCircle className="w-3.5 h-3.5" />
              <span className="font-medium">Available to borrow</span>
            </motion.div>
          )}
        </div>

        {/* Enhanced Floating Particles on Hover */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 5 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1.5 h-1.5 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full opacity-0 group-hover:opacity-60"
              style={{
                left: `${15 + i * 15}%`,
                top: `${20 + i * 15}%`,
              }}
              animate={{
                opacity: [0, 0.6, 0],
                scale: [0, 1.5, 0],
                y: [0, -30, -60],
                x: [0, Math.sin(i) * 20, Math.sin(i) * 40]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.3,
                ease: "easeOut"
              }}
            />
          ))}
        </div>

        {/* Corner Glow Effect */}
        <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-white/10 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-gradient-to-tr from-white/10 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </GlassCard>
    </motion.div>
  );
}