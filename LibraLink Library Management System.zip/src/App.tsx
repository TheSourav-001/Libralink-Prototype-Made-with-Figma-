import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import WelcomeScreen from "./components/WelcomeScreen";
import RoleSelection from "./components/RoleSelection";
import Authentication from "./components/Authentication";
import StudentDashboard from "./components/dashboards/StudentDashboard";
import FacultyDashboard from "./components/dashboards/FacultyDashboard";
import LibrarianDashboard from "./components/dashboards/LibrarianDashboard";
import AdminDashboard from "./components/dashboards/AdminDashboard";
import { Toaster } from "./components/ui/sonner";

export type UserRole =
  | "student"
  | "faculty"
  | "librarian"
  | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  universityId?: string;
}

export interface AppState {
  currentScreen:
    | "welcome"
    | "roleSelection"
    | "auth"
    | "dashboard";
  selectedRole: UserRole | null;
  user: User | null;
  authMode: "login" | "register";
}

const pageVariants = {
  initial: { opacity: 0, scale: 0.95, y: 20 },
  in: { opacity: 1, scale: 1, y: 0 },
  out: { opacity: 0, scale: 1.05, y: -20 },
};

const pageTransition = {
  type: "spring",
  stiffness: 300,
  damping: 30,
  duration: 0.4,
};

export default function App() {
  const [appState, setAppState] = useState<AppState>({
    currentScreen: "welcome",
    selectedRole: null,
    user: null,
    authMode: "login",
  });

  const [navigationHistory, setNavigationHistory] = useState<
    string[]
  >(["welcome"]);

  useEffect(() => {
    // Add beautiful gradient background
    document.body.style.background =
      "linear-gradient(135deg, #667eea 0%, #764ba2 100%)";
    document.body.style.minHeight = "100vh";

    return () => {
      document.body.style.background = "";
      document.body.style.minHeight = "";
    };
  }, []);

  const navigateForward = (
    screen: AppState["currentScreen"],
    role?: UserRole,
    authMode?: "login" | "register",
  ) => {
    setNavigationHistory((prev) => [...prev, screen]);
    setAppState((prev) => ({
      ...prev,
      currentScreen: screen,
      ...(role && { selectedRole: role }),
      ...(authMode && { authMode }),
    }));
  };

  const navigateBack = () => {
    if (navigationHistory.length > 1) {
      const newHistory = [...navigationHistory];
      newHistory.pop();
      const previousScreen = newHistory[
        newHistory.length - 1
      ] as AppState["currentScreen"];

      setNavigationHistory(newHistory);
      setAppState((prev) => ({
        ...prev,
        currentScreen: previousScreen,
        ...(previousScreen === "welcome" && {
          selectedRole: null,
        }),
        ...(previousScreen === "roleSelection" && {
          user: null,
        }),
      }));
    }
  };

  const handleLogin = (user: User) => {
    setAppState((prev) => ({
      ...prev,
      user,
      currentScreen: "dashboard",
    }));
    setNavigationHistory((prev) => [...prev, "dashboard"]);
  };

  const handleLogout = () => {
    setAppState({
      currentScreen: "welcome",
      selectedRole: null,
      user: null,
      authMode: "login",
    });
    setNavigationHistory(["welcome"]);
  };

  const renderCurrentScreen = () => {
    switch (appState.currentScreen) {
      case "welcome":
        return (
          <WelcomeScreen
            onGetStarted={() =>
              navigateForward("roleSelection")
            }
          />
        );

      case "roleSelection":
        return (
          <RoleSelection
            onRoleSelect={(role) =>
              navigateForward("auth", role)
            }
            onBack={navigateBack}
          />
        );

      case "auth":
        return (
          <Authentication
            role={appState.selectedRole!}
            mode={appState.authMode}
            onLogin={handleLogin}
            onSwitchMode={(mode) =>
              setAppState((prev) => ({
                ...prev,
                authMode: mode,
              }))
            }
            onBack={navigateBack}
          />
        );

      case "dashboard":
        const DashboardComponent = {
          student: StudentDashboard,
          faculty: FacultyDashboard,
          librarian: LibrarianDashboard,
          admin: AdminDashboard,
        }[appState.user!.role];

        return (
          <DashboardComponent
            user={appState.user!}
            onLogout={handleLogout}
            onBack={navigateBack}
          />
        );

      default:
        return (
          <WelcomeScreen
            onGetStarted={() =>
              navigateForward("roleSelection")
            }
          />
        );
    }
  };

  return (
    <div className="min-h-screen w-full relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800" />
        <motion.div
          className="absolute inset-0 opacity-20"
          animate={{
            background: [
              "radial-gradient(circle at 20% 50%, rgba(120, 100, 255, 0.2) 0%, transparent 50%)",
              "radial-gradient(circle at 80% 20%, rgba(255, 193, 7, 0.2) 0%, transparent 50%)",
              "radial-gradient(circle at 40% 80%, rgba(76, 175, 80, 0.2) 0%, transparent 50%)",
              "radial-gradient(circle at 20% 50%, rgba(120, 100, 255, 0.2) 0%, transparent 50%)",
            ],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      </div>

      {/* Main Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={appState.currentScreen}
          initial="initial"
          animate="in"
          exit="out"
          variants={pageVariants}
          transition={pageTransition}
          className="relative z-10"
        >
          {renderCurrentScreen()}
        </motion.div>
      </AnimatePresence>

      <Toaster />
    </div>
  );
}