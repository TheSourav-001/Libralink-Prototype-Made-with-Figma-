import { allBooks } from './books';

export const adminStats = {
  totalUsers: 1247,
  activeUsers: 892,
  totalBooks: allBooks.length,
  systemUptime: '99.8%',
  totalRevenue: 125430,
  monthlyGrowth: 12.5,
  overdueBooks: 23,
  systemAlerts: 3
};

export const userStats = [
  { role: 'Students', count: 1089, color: 'indigo' as const, growth: '+8.2%' },
  { role: 'Faculty', count: 134, color: 'amber' as const, growth: '+3.1%' },
  { role: 'Librarians', count: 18, color: 'green' as const, growth: '+1.5%' },
  { role: 'Admins', count: 6, color: 'red' as const, growth: '0%' }
];

export const recentActivities = [
  { action: 'New user registration', user: 'John Smith', time: '2 minutes ago', type: 'user' as const },
  { action: 'Book added to inventory', user: 'Librarian Jane', time: '15 minutes ago', type: 'book' as const },
  { action: 'System backup completed', user: 'System', time: '1 hour ago', type: 'system' as const },
  { action: 'Payment processed', user: 'Alice Johnson', time: '2 hours ago', type: 'payment' as const },
  { action: 'Security scan completed', user: 'System', time: '6 hours ago', type: 'security' as const }
];

export const systemAlerts = [
  { level: 'warning' as const, message: 'Database backup overdue', time: '2 hours ago' },
  { level: 'info' as const, message: 'System maintenance scheduled', time: '1 day ago' },
  { level: 'error' as const, message: 'Failed login attempts detected', time: '3 hours ago' }
];

export const analyticsData = {
  popularCategories: [
    { name: 'Fiction', percentage: 80 },
    { name: 'Science', percentage: 65 },
    { name: 'Technology', percentage: 50 },
    { name: 'Fantasy', percentage: 35 },
    { name: 'Business', percentage: 20 }
  ],
  userActivity: {
    activeStudents: 156,
    activeFaculty: 23,
    booksBorrowedToday: 42,
    overdueBooks: 8
  }
};