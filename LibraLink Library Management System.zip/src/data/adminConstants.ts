import { 
  Activity,
  HardDrive,
  Database,
  Wifi,
  Users,
  Shield,
  UserX
} from 'lucide-react';

export interface SystemAlert {
  id: string;
  type: 'critical' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: string;
}

export interface SystemMetric {
  name: string;
  value: string;
  status: 'good' | 'warning' | 'critical';
  icon: React.ElementType;
}

export const mockAlerts: SystemAlert[] = [
  {
    id: '1',
    type: 'critical',
    title: 'Database Connection Issue',
    message: 'Primary database experiencing high latency',
    timestamp: '2 minutes ago'
  },
  {
    id: '2',
    type: 'warning',
    title: 'High Memory Usage',
    message: 'Server memory usage at 85%',
    timestamp: '15 minutes ago'
  },
  {
    id: '3',
    type: 'info',
    title: 'Backup Completed',
    message: 'Daily backup completed successfully',
    timestamp: '1 hour ago'
  }
];

export const systemMetrics: SystemMetric[] = [
  { name: 'CPU Usage', value: '45%', status: 'good', icon: Activity },
  { name: 'Memory Usage', value: '78%', status: 'warning', icon: HardDrive },
  { name: 'Disk Space', value: '62%', status: 'good', icon: Database },
  { name: 'Network', value: '99.9%', status: 'good', icon: Wifi }
];

export const userStats = {
  totalUsers: 179,
  activeUsers: 156,
  newUsersToday: 8,
  bannedUsers: 3,
  students: 156,
  faculty: 23,
  librarians: 3,
  admins: 1
};

export const systemStats = {
  uptime: '99.9%',
  totalBooks: 1247,
  totalTransactions: 15678,
  activeConnections: 89,
  dataTransfer: '2.4TB',
  backupStatus: 'Completed',
  lastBackup: '2 hours ago',
  storageUsed: '78%'
};

export const adminTabs = [
  { id: 'overview', label: 'Overview', icon: 'BarChart3' },
  { id: 'users', label: 'User Management', icon: 'Users' },
  { id: 'system', label: 'System Health', icon: 'Server' },
  { id: 'analytics', label: 'Analytics', icon: 'TrendingUp' },
  { id: 'settings', label: 'Settings', icon: 'Settings' }
];