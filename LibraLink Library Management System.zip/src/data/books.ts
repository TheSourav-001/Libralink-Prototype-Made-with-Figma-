export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  publication: string;
  year: number;
  category: string;
  description: string;
  coverUrl: string;
  status: 'available' | 'borrowed' | 'reserved';
  rating: number;
  borrowedBy?: string;
  dueDate?: string;
  reservedBy?: string;
}

export const books: Book[] = [
  // Fiction
  {
    id: '1',
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    isbn: '978-0-06-112008-4',
    publication: 'J.B. Lippincott & Co.',
    year: 1960,
    category: 'Fiction',
    description: 'A classic novel exploring themes of racial injustice and moral growth in Depression-era Alabama.',
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.8
  },
  {
    id: '2',
    title: '1984',
    author: 'George Orwell',
    isbn: '978-0-452-28423-4',
    publication: 'Secker & Warburg',
    year: 1949,
    category: 'Fiction',
    description: 'A dystopian social science fiction novel and cautionary tale about totalitarianism.',
    coverUrl: 'https://images.unsplash.com/photo-1495640388908-05fa85288e61?w=300&h=400&fit=crop',
    status: 'borrowed',
    rating: 4.7,
    borrowedBy: 'student1',
    dueDate: '2024-01-15'
  },
  {
    id: '3',
    title: 'Pride and Prejudice',
    author: 'Jane Austen',
    isbn: '978-0-14-143951-8',
    publication: 'T. Egerton',
    year: 1813,
    category: 'Fiction',
    description: 'A romantic novel that critiques the British landed gentry at the end of the 18th century.',
    coverUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.6
  },
  {
    id: '4',
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    isbn: '978-0-7432-7356-5',
    publication: 'Charles Scribner\'s Sons',
    year: 1925,
    category: 'Fiction',
    description: 'A novel about the American Dream and the Jazz Age, set in the summer of 1922.',
    coverUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop',
    status: 'reserved',
    rating: 4.5,
    reservedBy: 'faculty1'
  },
  {
    id: '5',
    title: 'Harry Potter and the Philosopher\'s Stone',
    author: 'J.K. Rowling',
    isbn: '978-0-7475-3269-9',
    publication: 'Bloomsbury',
    year: 1997,
    category: 'Fantasy',
    description: 'The first novel in the Harry Potter series about a young wizard\'s adventures.',
    coverUrl: 'https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.9
  },

  // Science & Technology
  {
    id: '6',
    title: 'Sapiens: A Brief History of Humankind',
    author: 'Yuval Noah Harari',
    isbn: '978-0-06-231609-7',
    publication: 'Harvill Secker',
    year: 2011,
    category: 'Science',
    description: 'An exploration of how Homo sapiens came to dominate the world.',
    coverUrl: 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.7
  },
  {
    id: '7',
    title: 'The Elegant Universe',
    author: 'Brian Greene',
    isbn: '978-0-393-05858-0',
    publication: 'W. W. Norton & Company',
    year: 1999,
    category: 'Physics',
    description: 'An introduction to string theory and the quest for the ultimate theory of physics.',
    coverUrl: 'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.4
  },
  {
    id: '8',
    title: 'Algorithms to Live By',
    author: 'Brian Christian',
    isbn: '978-1-4767-2751-1',
    publication: 'Henry Holt and Company',
    year: 2016,
    category: 'Computer Science',
    description: 'How computer algorithms can be applied to everyday life decisions.',
    coverUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300&h=400&fit=crop',
    status: 'borrowed',
    rating: 4.6,
    borrowedBy: 'student2',
    dueDate: '2024-01-20'
  },

  // Business & Economics
  {
    id: '9',
    title: 'Thinking, Fast and Slow',
    author: 'Daniel Kahneman',
    isbn: '978-0-374-27563-1',
    publication: 'Farrar, Straus and Giroux',
    year: 2011,
    category: 'Psychology',
    description: 'A groundbreaking tour of the mind and explains the two systems that drive the way we think.',
    coverUrl: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.8
  },
  {
    id: '10',
    title: 'The Lean Startup',
    author: 'Eric Ries',
    isbn: '978-0-307-88789-4',
    publication: 'Crown Business',
    year: 2011,
    category: 'Business',
    description: 'A methodology for developing businesses and products based on validated learning.',
    coverUrl: 'https://images.unsplash.com/photo-1556075798-4825dfaaf498?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.5
  },

  // Additional books to reach 100+
  {
    id: '11',
    title: 'The Hobbit',
    author: 'J.R.R. Tolkien',
    isbn: '978-0-547-92822-7',
    publication: 'George Allen & Unwin',
    year: 1937,
    category: 'Fantasy',
    description: 'A children\'s fantasy novel about the adventures of hobbit Bilbo Baggins.',
    coverUrl: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.7
  },
  {
    id: '12',
    title: 'The Catcher in the Rye',
    author: 'J.D. Salinger',
    isbn: '978-0-316-76948-0',
    publication: 'Little, Brown and Company',
    year: 1951,
    category: 'Fiction',
    description: 'A coming-of-age story featuring the rebellious teenager Holden Caulfield.',
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.3
  },
  {
    id: '13',
    title: 'Educated',
    author: 'Tara Westover',
    isbn: '978-0-399-59050-4',
    publication: 'Random House',
    year: 2018,
    category: 'Memoir',
    description: 'A memoir about a woman who grows up in a survivalist family and eventually earns a PhD.',
    coverUrl: 'https://images.unsplash.com/photo-1519791883288-dc8bd696e667?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.6
  },
  {
    id: '14',
    title: 'The Silent Patient',
    author: 'Alex Michaelides',
    isbn: '978-1-250-30169-7',
    publication: 'Celadon Books',
    year: 2019,
    category: 'Thriller',
    description: 'A psychological thriller about a woman who refuses to speak after allegedly murdering her husband.',
    coverUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop',
    status: 'borrowed',
    rating: 4.4,
    borrowedBy: 'student3',
    dueDate: '2024-01-18'
  },
  {
    id: '15',
    title: 'Atomic Habits',
    author: 'James Clear',
    isbn: '978-0-7352-1129-2',
    publication: 'Avery',
    year: 2018,
    category: 'Self-Help',
    description: 'A guide to building good habits and breaking bad ones through small changes.',
    coverUrl: 'https://images.unsplash.com/photo-1526285759904-71d1170ed2ac?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.8
  },

  // Continue with more books...
  {
    id: '16',
    title: 'The Midnight Library',
    author: 'Matt Haig',
    isbn: '978-0-525-55948-1',
    publication: 'Viking',
    year: 2020,
    category: 'Fiction',
    description: 'A novel about a magical library between life and death.',
    coverUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.5
  },
  {
    id: '17',
    title: 'Becoming',
    author: 'Michelle Obama',
    isbn: '978-1-5247-6313-8',
    publication: 'Crown',
    year: 2018,
    category: 'Biography',
    description: 'The memoir of the former First Lady of the United States.',
    coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.7
  },
  {
    id: '18',
    title: 'The 7 Habits of Highly Effective People',
    author: 'Stephen Covey',
    isbn: '978-1-982-13750-9',
    publication: 'Free Press',
    year: 1989,
    category: 'Self-Help',
    description: 'A guide to personal effectiveness and leadership principles.',
    coverUrl: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.6
  },
  {
    id: '19',
    title: 'The Power of Now',
    author: 'Eckhart Tolle',
    isbn: '978-1-57731-152-2',
    publication: 'Namaste Publishing',
    year: 1997,
    category: 'Spirituality',
    description: 'A guide to spiritual enlightenment through present-moment awareness.',
    coverUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.4
  },
  {
    id: '20',
    title: 'Dune',
    author: 'Frank Herbert',
    isbn: '978-0-441-17271-9',
    publication: 'Chilton Books',
    year: 1965,
    category: 'Science Fiction',
    description: 'An epic science fiction novel set in the distant future on the desert planet Arrakis.',
    coverUrl: 'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=300&h=400&fit=crop',
    status: 'available',
    rating: 4.8
  }
];

// Generate more books to reach 100+
const generateMoreBooks = (): Book[] => {
  const additionalBooks = [];
  const titles = [
    'The Alchemist', 'Life of Pi', 'The Book Thief', 'The Kite Runner', 'Where the Crawdads Sing',
    'The Seven Husbands of Evelyn Hugo', 'Project Hail Mary', 'Klara and the Sun', 'The Thursday Murder Club',
    'The Guest List', 'The Sanatorium', 'The Hunting Party', 'Gone Girl', 'The Girl with the Dragon Tattoo',
    'The Da Vinci Code', 'Angels and Demons', 'The Hunger Games', 'Divergent', 'The Maze Runner',
    'Twilight', 'The Fault in Our Stars', 'Me Before You', 'All the Light We Cannot See', 'The Nightingale',
    'The Pillars of the Earth', 'A Game of Thrones', 'The Fellowship of the Ring', 'The Lion, the Witch and the Wardrobe',
    'Brave New World', 'Fahrenheit 451', 'The Handmaid\'s Tale', 'The Road', 'Life After Life',
    'The Time Traveler\'s Wife', 'Outlander', 'The Help', 'Water for Elephants', 'The Secret Garden',
    'Jane Eyre', 'Wuthering Heights', 'Great Expectations', 'The Picture of Dorian Gray', 'Dracula',
    'Frankenstein', 'The Strange Case of Dr. Jekyll and Mr. Hyde', 'The Count of Monte Cristo', 'Les Misérables',
    'War and Peace', 'Anna Karenina', 'Crime and Punishment', 'The Brothers Karamazov', 'One Hundred Years of Solitude',
    'Love in the Time of Cholera', 'The Old Man and the Sea', 'For Whom the Bell Tolls', 'The Sun Also Rises',
    'Catch-22', 'Slaughterhouse-Five', 'The Grapes of Wrath', 'Of Mice and Men', 'East of Eden',
    'The Outsiders', 'Lord of the Flies', 'Animal Farm', 'Brave New World', 'The Giver',
    'The Chronicles of Narnia', 'His Dark Materials', 'The Golden Compass', 'The Subtle Knife', 'The Amber Spyglass',
    'The Stand', 'It', 'The Shining', 'Pet Sematary', 'Carrie', 'Misery', 'The Green Mile',
    'The Dark Tower', 'Salem\'s Lot', 'The Dead Zone', 'Firestarter', 'Christine', 'Cujo',
    'The Talisman', 'Black House', 'Bag of Bones', 'Hearts in Atlantis', 'Everything\'s Eventual',
    'Doctor Sleep', '11/22/63', 'Mr. Mercedes', 'Finders Keepers', 'End of Watch', 'The Outsider',
    'Later', 'Billy Summers', 'Fairy Tale'
  ];

  const authors = [
    'Paulo Coelho', 'Yann Martel', 'Markus Zusak', 'Khaled Hosseini', 'Delia Owens',
    'Taylor Jenkins Reid', 'Andy Weir', 'Kazuo Ishiguro', 'Richard Osman', 'Lucy Foley',
    'Sarah Pearse', 'Lucy Clarke', 'Gillian Flynn', 'Stieg Larsson', 'Dan Brown',
    'Dan Brown', 'Suzanne Collins', 'Veronica Roth', 'James Dashner', 'Stephenie Meyer',
    'John Green', 'Jojo Moyes', 'Anthony Doerr', 'Kristin Hannah', 'Ken Follett'
  ];

  const categories = [
    'Fiction', 'Fantasy', 'Science Fiction', 'Mystery', 'Thriller', 'Romance', 'Horror',
    'Historical Fiction', 'Contemporary Fiction', 'Literary Fiction', 'Young Adult',
    'Biography', 'Memoir', 'Self-Help', 'Business', 'Science', 'Psychology', 'Philosophy'
  ];

  const coverUrls = [
    'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1495640388908-05fa85288e61?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1589998059171-988d887df646?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1556075798-4825dfaaf498?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1519791883288-dc8bd696e667?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1526285759904-71d1170ed2ac?w=300&h=400&fit=crop',
    'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300&h=400&fit=crop'
  ];

  for (let i = 0; i < 80; i++) {
    const titleIndex = i % titles.length;
    const authorIndex = i % authors.length;
    const categoryIndex = i % categories.length;
    const coverIndex = i % coverUrls.length;
    
    additionalBooks.push({
      id: (21 + i).toString(),
      title: titles[titleIndex],
      author: authors[authorIndex],
      isbn: `978-${Math.floor(Math.random() * 10)}-${Math.floor(Math.random() * 1000)}-${Math.floor(Math.random() * 10000)}-${Math.floor(Math.random() * 10)}`,
      publication: 'Publisher Name',
      year: 1990 + Math.floor(Math.random() * 34),
      category: categories[categoryIndex],
      description: `A compelling ${categories[categoryIndex].toLowerCase()} that explores themes of human nature, society, and personal growth.`,
      coverUrl: coverUrls[coverIndex],
      status: Math.random() > 0.7 ? 'borrowed' : Math.random() > 0.5 ? 'reserved' : 'available',
      rating: 3.5 + Math.random() * 1.5,
      ...(Math.random() > 0.8 && {
        borrowedBy: `student${Math.floor(Math.random() * 10)}`,
        dueDate: new Date(Date.now() + Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      }),
      ...(Math.random() > 0.9 && {
        reservedBy: `faculty${Math.floor(Math.random() * 5)}`
      })
    });
  }

  return additionalBooks;
};

export const allBooks = [...books, ...generateMoreBooks()];

export const getBooksByCategory = (category: string) => 
  allBooks.filter(book => book.category.toLowerCase() === category.toLowerCase());

export const searchBooks = (query: string) => 
  allBooks.filter(book => 
    book.title.toLowerCase().includes(query.toLowerCase()) ||
    book.author.toLowerCase().includes(query.toLowerCase()) ||
    book.category.toLowerCase().includes(query.toLowerCase())
  );

export const getBookById = (id: string) => 
  allBooks.find(book => book.id === id);

export const getAvailableBooks = () => 
  allBooks.filter(book => book.status === 'available');

export const getBorrowedBooks = (userId: string) => 
  allBooks.filter(book => book.borrowedBy === userId);

export const getReservedBooks = (userId: string) => 
  allBooks.filter(book => book.reservedBy === userId);